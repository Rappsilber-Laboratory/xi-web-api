"""Module for False Discovery Rate (FDR) estimation."""
import subprocess


def calculate_fdr(n_tt, n_td, n_dd):
    """
    Calculate FDR value.

    :param n_tt: (int) number of target-target matches
    :param n_td: (int) number of target-decoy matches
    :param n_dd: (int) number of decoy-decoy matches
    :return:
    """
    return (n_td - n_dd) / n_tt


def add_fdr(search_res_df, score_field, decoy1_field, decoy2_field):
    """
    Estimate a target-decoy based FDR for PSMSs of xiSEARCH2.

    :param search_res_df: (pandas df) search results with residue positions in protein.
    :param score_field: name of score column to calculate fdr on
    :param decoy1_field: name of decoy1 column
    :param decoy2_field: name of decoy2 column
    :return: input dataframe with additional column of fdr values.
    """
    # sort df by score
    search_df_sorted = search_res_df.sort_values(score_field)

    # get target / decoy flags
    tt_mask = (~search_df_sorted[decoy1_field] & ~search_df_sorted[decoy2_field])
    td_mask = (~search_df_sorted[decoy1_field] & search_df_sorted[decoy2_field]) \
        | (search_df_sorted[decoy1_field] & ~search_df_sorted[decoy2_field])
    dd_mask = (search_df_sorted[decoy1_field] & search_df_sorted[decoy2_field])

    # calculate first fdr
    fdr_i = round(calculate_fdr(sum(tt_mask),
                                sum(td_mask),
                                sum(dd_mask)), ndigits=3)
    fdr_ls = []

    for i in range(len(search_df_sorted)):
        # append fdr values
        fdr_ls.append(fdr_i)
        # for each decoy match calculate fdr new for following matches
        if not tt_mask.iloc[i]:
            n_tt = sum(tt_mask.iloc[i + 1:])
            n_td = sum(td_mask.iloc[i + 1:])
            n_dd = sum(dd_mask.iloc[i + 1:])
            fdr_new = round(calculate_fdr(n_tt, n_td, n_dd), ndigits=3)
            fdr_i = min(fdr_i, fdr_new)

    # add column to df
    search_df_sorted.loc[:, 'fdr'] = fdr_ls
    return search_df_sorted


def add_distance(search_res_df, distance_df, link_columns=('protein_link_p1', 'protein_link_p2')):
    """
    Return dataframe with a distance assigned to each residue pair.

    :param search_res_df: (pandas df) search results with residue positions in protein.
    :param distance_df: (pandas df) dataframe containing distances between residues.
    :param link_columns: (list of str) column names containing the linked residue positions
    :return: input dataframe with additional column of distance.
    """
    res_ls = []
    link_cols = search_res_df[[link_columns[0], link_columns[1]]].astype(str)
    for i in range(len(link_cols)):
        # sort matched residues (sorted in distance df)
        from_sites = link_cols.iloc[i][link_columns[0]].split(';')
        to_sites = link_cols.iloc[i][link_columns[1]].split(';')

        distances = []
        for from_site in from_sites:
            for to_site in to_sites:
                residues = sorted([int(from_site), int(to_site)])
                # -1 for linear results
                if residues[0] == '' or residues[1] == '':
                    res_ls.append(-1)
                else:
                    try:
                        distance = distance_df[
                            (distance_df['residue_1'] == int(residues[0]))
                            & (distance_df['residue_2'] == int(residues[1]))]['distance']
                        distances.append(distance.iloc[0])
                    except IndexError:
                        # if residues not in df (not part of crystal structure) append -1
                        distances.append(-1)
        res_ls.append(min(distances))

    # add column to df
    search_res_df.loc[:, 'distance'] = res_ls

    return search_res_df


def call_xifdr(infile, params, out_path, out_base_name):
    """
    Run xiFDR on xi2 tsv result file.

    :param infile: (str) path to the xi2 result file
    :param params: (list str) command line parameters
    :param out_path: (str) out path
    :param out_base_name: (str) base name of the xiFDR result files
    """
    standard_cmds = ['/usr/bin/java', '-cp',
                     params['xiFDR_path'], 'org.rappsilber.fdr.CSVinFDR']

    settings = ' '.join([subprocess.list2cmdline(params['arguments']),
                         f'--csvOutDir="{out_path}"'])

    for fdr_setting in params['fdrs']:
        cmd_string = ' '.join([
            subprocess.list2cmdline(standard_cmds),
            settings,
            subprocess.list2cmdline(params['fdrs'][fdr_setting]),
            f'--csvBaseName={fdr_setting}_{out_base_name}',
            infile
        ])
        xi_fdr = subprocess.Popen(cmd_string, shell=True)
        xi_fdr.communicate()
