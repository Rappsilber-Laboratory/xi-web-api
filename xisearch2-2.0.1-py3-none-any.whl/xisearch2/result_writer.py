"""
This module contains the ResultWriter classes for writing out xiSEARCH2 results.

Available ResultWriters are:
    - TsvResultWriter: writes results to tsv file
    - MemoryResultWriter: writes results to a list in memory
"""

from abc import ABC, abstractmethod
import re
from xisearch2.output_format import create_mod_str, create_mod_mass_str, create_mod_pos_str
import pandas as pd
import numpy as np


class ResultWriter(ABC):
    """Base class for the different ways to write out search results."""

    ordered_output_columns = [
        'run_name',  # run name parsed from peaklist file
        'scan_index',  # index of the scan
        'scan_number',  # scan number
        'match_score',  # final score of the match
        'top_ranking',  # top ranking match for this scan
        'sequence_p1',  # AA sequence (incl. modifications) of p1
        'sequence_p2',  # AA sequence (incl. modifications) of p2
        'link_pos_p1',  # linked AA residue position in p1
        'link_pos_p2',  # linked AA residue position in p2
        'protein_p1',  # protein(s) p1 could come from
        'protein_p2',  # protein(s) p2 could come from
        'protein_link_p1',  # link position(s) in the protein(s) for p1
        'protein_link_p2',  # link position(s) in the protein(s) for p2
        'decoy_p1',  # if p1 is a decoy peptide
        'decoy_p2',  # if p2 is a decoy peptide
        'base_sequence_p1',  # AA seq without modifications of p1
        'base_sequence_p2',  # AA seq without modifications of p2
        'mass_p1',  # neutral mass of p1
        'mass_p2',  # neutral mass of p2
        'linked_aa_p1',  # Amino acid that is linked on p1
        'linked_aa_p2',  # Amino acid that is linked on p2
        'aa_len_p1',  # number of amino acids in p1
        'aa_len_p2',  # number of amino acids in p2
        'peaklist_file',  # name of the peaklist file
        'source',  # path to peaklist source
        'spectrum_mz',  # precursor mz from the spectrum
        'spectrum_charge',  # precursor charge state from the spectrum
        'precursor_mz',  # m/z of the precursor (potentially corrected)
        'precursor_missing_isotope_peak',  # how many missing isotopic peaks are assumed
        'precursor_charge',  # precursor charge state (potentially corrected)
        'precursor_mass',  # neutral mass of the precursor
        'precursor_intensity',  # intensity of the precursor
        'retention_time',  # retention time in seconds
        'calc_mass',  # theoretical/calculated mass
        'calc_mz',  # theoretical/calculated m/z
        'linear',  # linear or crosslinked peptide
        'crosslinker_name',  # name of the crosslinker
        'crosslinker_mass',  # mass of the crosslinker
        'start_pos_p1',  # start position(s) of p1 in the protein(s)
        'start_pos_p2',  # start position(s) of p2 in the protein(s)
        'fasta_p1',  # fasta header(s) of p1
        'fasta_p2',  # fasta header(s) of p2
        'position_count_p1',  # how often p1 occurs in the fasta(s)
        'position_count_p2',  # how often p2 occurs in the fasta(s)
        'protein_count_p1',  # in how many different proteins p1 occurs
        'protein_count_p2',  # in how many different proteins p2 occurs
        'mods_p1',  # modification(s) in p1
        'mods_p2',  # modification(s) in p2
        'mod_pos_p1',  # position(s) of modification(s) in p1
        'mod_pos_p2',  # position(s) of modification(s) in p2
        'mod_mass_p1',  # mass(es) of modification(s) in p1
        'mod_mass_p2',  # mass(es) of modification(s) in p2
        'alpha_id',  # alpha pep_id (1 or 2, if alpha pep is p1 or p2)
        'alpha_rank',  # rank of the alpha peptide
        'alpha_score',  # score of the alpha peptide
        'alpha_delta_score',  # delta score to the second best unique alpha score
        'beta_id',  # beta pep_id (1 or 2, if beta pep is p1 or p2)
        'beta_score',  # score of the beta peptide
        'beta_count',  # number of beta peptides found for this alpha peptide
        'beta_count_inverse',  # inverse of beta_count
        'alpha_beta_rank',  # rank of the alpha beta candidate
        'alpha_beta_score',  # score of the alpha beta candidate
        'alpha_beta_delta_score',  # delta score to the second best unique alpha_beta score
        'alpha_beta_sum',  # sum of alpha and beta scores
        # misc sub scores
        'link_score_site_p1',  # possible link sites on p1
        'link_score_site_p2',  # possible link sites on p2
        'link_score',  # scores for possible link sites
        'var_mod_count_p1',  # variable modification count of p1
        'var_mod_count_p2',  # variable modification count of p2
        'var_mod_count_pp',  # variable modification count of the peptide pair
        'total_fragments_p1',
        'total_fragments_p2',
        'total_fragments_pp',
        'primary_fragments_p1',
        'primary_fragments_p2',
        'primary_fragments_pp',
        'loss_fragments_p1',
        'loss_fragments_p2',
        'loss_fragments_pp',
        'all_fragsites_p1',
        'all_fragsites_p2',
        'all_fragsites_pp',
        'all_coverage_p1',
        'all_coverage_p2',
        'all_coverage_pp',
        'primary_fragsites_p1',
        'primary_fragsites_p2',
        'primary_fragsites_pp',
        'primary_coverage_p1',
        'primary_coverage_p2',
        'primary_coverage_pp',
        'loss_fragsites_p1',
        'loss_fragsites_p2',
        'loss_fragsites_pp',
        'loss_coverage_p1',
        'loss_coverage_p2',
        'loss_coverage_pp',
        'conservative_fragsites_p1',
        'conservative_fragsites_p2',
        'conservative_fragsites_pp',
        'conservative_coverage_p1',
        'conservative_coverage_p2',
        'conservative_coverage_pp',
        'conservative_multi_fragsites_p1',
        'conservative_multi_fragsites_p2',
        'conservative_multi_fragsites_pp',
        'conservative_multi_coverage_p1',
        'conservative_multi_coverage_p2',
        'conservative_multi_coverage_pp',
        'unique_peak_fragsites_p1',
        'unique_peak_fragsites_p2',
        'unique_peak_fragsites_pp',
        'unique_peak_coverage_p1',
        'unique_peak_coverage_p2',
        'unique_peak_coverage_pp',
        'unique_peak_primary_fragsites_p1',
        'unique_peak_primary_fragsites_p2',
        'unique_peak_primary_fragsites_pp',
        'unique_peak_primary_coverage_p1',
        'unique_peak_primary_coverage_p2',
        'unique_peak_primary_coverage_pp',
        'unique_peak_loss_fragsites_p1',
        'unique_peak_loss_fragsites_p2',
        'unique_peak_loss_fragsites_pp',
        'unique_peak_loss_coverage_p1',
        'unique_peak_loss_coverage_p2',
        'unique_peak_loss_coverage_pp',
        'unique_peak_conservative_fragsites_p1',
        'unique_peak_conservative_fragsites_p2',
        'unique_peak_conservative_fragsites_pp',
        'unique_peak_conservative_coverage_p1',
        'unique_peak_conservative_coverage_p2',
        'unique_peak_conservative_coverage_pp',
        'unique_peak_primary_crosslink_fragsites_p1',
        'unique_peak_primary_crosslink_fragsites_p2',
        'unique_peak_primary_crosslink_fragsites_pp',
        'unique_peak_conservative_crosslink_fragsites_p1',
        'unique_peak_conservative_crosslink_fragsites_p2',
        'unique_peak_conservative_crosslink_fragsites_pp',
        'sequence_tag_fragsites_p1',
        'sequence_tag_fragsites_p2',
        'sequence_tag_fragsites_pp',
        'sequence_tag_coverage_p1',
        'sequence_tag_coverage_p2',
        'sequence_tag_coverage_pp',
        'fragment_error_ppm_mean',
        'fragment_error_ppm_abs_mean',
        'fragment_error_ppm_abs_lin_p1_mean',
        'fragment_error_ppm_abs_lin_p2_mean',
        'fragment_error_ppm_abs_cl_mean',
        'fragment_error_ppm_mean_square',
        'fragment_error_ppm_mean_square_root',
        'fragment_error_normalized_mean',
        'fragment_error_1-normalized_mean',
        'precursor_error',
        'precursor_error_ppm',
        'precursor_error_ppm_abs',
        'precursor_error_normalized',
        'precursor_error_1-normalized',
        'frag_max_charge',
        'frag_mean_charge',
        'rel_frag_max_charge',
        'rel_frag_mean_charge',
        'intensity_coverage',
        'primary_intensity_coverage',
        'conservative_intensity_coverage',
        'isotope_intensity_coverage',
        'isotope_intensity_matched_fraction',
        'isotope_peak_matched_fraction',
        'single_peak_coverage',
        'top10_peak_coverage',
        'top10_peak_coverage_limited',
        'top20_peak_coverage',
        'top20_peak_coverage_limited',
        'top40_peak_coverage',
        'top40_peak_coverage_limited',
        'top100_peak_coverage',
        'top100_peak_coverage_limited',
        'total_peak_coverage',
        'fragment_library_score',
        'fragment_library_score_log',
        'fragment_library_score_exponential',
        # delta scores
        'delta',
        'delta_mod',
        'delta_combined',
        # combined scores
        'spectrum_quality_score',
        'p1_score',
        'p2_score',
        'auto_validation',
    ]

    @abstractmethod
    def __init__(self, context):
        self.context = context

    @abstractmethod
    def write(self, result):
        """
        Write result.

        :param result: (np.array) result to write.
        """
        pass

    @abstractmethod
    def close(self):
        """Close the writer."""
        pass

    def put(self, result):
        self.write(result)

    def _to_dataframe(self, results):
        """
        Convert result to pandas DataFrame.

        :param results: (list of tuples) list of result tuples to convert.
            (np.array) spectrum match results.
            (np.array) protein link sites.
        :return:
        """
        context = self.context
        # convert numpy struct arrays to pandas Dataframes
        # For the result_df we need to create a DataFrame from each result an concatenate them
        # because the length of the string data types do not match.
        xl_names = np.array([xl.name for xl in context.config.crosslinker] + [''])
        xl_masses = np.array([xl.mass for xl in context.config.crosslinker] + [np.nan])
        result_df = pd.concat(
            [pd.concat(
                [
                    # direct forwarded match info
                    pd.DataFrame(r.matches),
                    # spectrum info
                    self._replicate_spectrum_info(r),
                    # crosslinker info
                    self._crosslinker_info_to_dataframe(r, xl_names, xl_masses),
                    # peptide info
                    self._peptide_info_to_dataframe(r)
                ], axis=1)
                for r in results],
            ignore_index=True)

        # fix base_sequence for linears
        linear_mask = result_df['p2_index'] == -1
        result_df.loc[linear_mask, 'base_sequence_p2'] = ''

        # change link_pos to 1-based for output
        result_df["link_pos_p1"] = result_df["link_pos_p1"].map(
            lambda x: x + 1 if x != -1 else x
        )
        result_df["link_pos_p2"] = result_df["link_pos_p2"].map(
            lambda x: x + 1 if x != -1 else x
        )

        # write result index
        enum_result_arr = np.arange(len(results))
        result_df['result_idx'] = np.repeat(
            enum_result_arr, [len(r.matches) for r in results]
        )

        # For protein link sites we can simply concatenate all and then turn it into a DataFrame.
        prot_link_sites_df = pd.DataFrame(
            np.concatenate([r.protein_link_sites for r in results])
        )
        prot_link_sites_df["result_idx"] = np.repeat(
            enum_result_arr, [len(r.protein_link_sites) for r in results]
        )

        # create protein_df to fill in protein related info
        protein_df = pd.DataFrame()
        prot_group = prot_link_sites_df.groupby(["result_idx", "alpha_beta_index"])
        # protein accessions
        protein_df[["protein_p1", "protein_p2"]] = prot_group.agg(
            {
                "prot1": lambda x: ";".join(context.proteins[x]["accession"]),
                "prot2": lambda x: ";".join(context.proteins[x[x >= 0]]["accession"]),
            }
        )
        # Fasta header
        protein_df[["fasta_p1", "fasta_p2"]] = prot_group.agg(
            {
                "prot1": lambda x: ";".join(context.proteins[x]["header"]),
                "prot2": lambda x: ";".join(context.proteins[x[x >= 0]]["header"]),
            }
        )
        # start position of the peptide and link sites in the protein
        protein_df[
            ["start_pos_p1", "start_pos_p2", "protein_link_p1", "protein_link_p2"]
        ] = prot_group.agg(
            {
                # aggregate as 1-based, semicolon separated strings ignoring linears (-1)
                "pep_pos1": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "pep_pos2": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "link_pos1": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                "link_pos2": lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
            }
        )
        # protein_count from how many distinct proteins could this peptide come from
        protein_df[["protein_count_p1", "protein_count_p2"]] = prot_group.agg(
            {"prot1": lambda x: x.nunique(), "prot2": lambda x: x[x >= 0].nunique()}
        )
        # position count how often does that peptide occur in the fasta
        protein_df[["position_count_p1", "position_count_p2"]] = prot_group.agg(
            {"prot1": lambda x: x.count(), "prot2": lambda x: x[x >= 0].count()}
        )
        # join protein related info to result df
        result_df = result_df.join(protein_df, on=["result_idx", "alpha_beta_index"])

        # create pep link sites score df
        pep_link_sites_info_df = pd.DataFrame(np.concatenate(
            [r.peptide_link_sites_info[['alpha_beta_index', 'link_p1', 'link_p2', 'score']]
             for r in results])
        )
        pep_link_sites_info_df['result_idx'] = np.repeat(
            enum_result_arr, [len(r.peptide_link_sites_info) for r in results]
        )
        # create pep_site_score_df and aggregate link score site info
        pep_site_score_df = pd.DataFrame()
        pep_link_sites_info_df['score'] = pep_link_sites_info_df['score'].astype(str)
        pep_group = pep_link_sites_info_df.groupby(['result_idx', 'alpha_beta_index'])
        pep_site_score_df[
            ['link_score_site_p1', 'link_score_site_p2', 'link_score']] = pep_group.agg(
            {
                # aggregate as 1-based, semicolon separated strings ignoring linear and non-cov(-1)
                'link_p1': lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                'link_p2': lambda x: ";".join(x[x >= 0].__add__(1).astype(str)),
                'score': ';'.join
            }
        )
        # set link score array to empty string for non-crosslink matches
        pep_site_score_df.loc[pep_site_score_df['link_score_site_p1'] == '', 'link_score'] = ''
        # join pep site score related info to result df
        result_df = result_df.join(pep_site_score_df, on=['result_idx', 'alpha_beta_index'])

        # fill in modification information
        result_df["mods_p1"] = create_mod_str(context, result_df["p1_index"])
        result_df["mod_pos_p1"] = create_mod_pos_str(context, result_df["p1_index"])
        result_df["mod_mass_p1"] = create_mod_mass_str(context, result_df["p1_index"])
        cl_mask = result_df["p2_index"] >= 0
        result_df.loc[cl_mask, "mods_p2"] = create_mod_str(
            context, result_df[cl_mask]["p2_index"]
        )
        result_df.loc[cl_mask, "mod_pos_p2"] = create_mod_pos_str(
            context, result_df[cl_mask]["p2_index"]
        )
        result_df.loc[cl_mask, "mod_mass_p2"] = create_mod_mass_str(
            context, result_df[cl_mask]["p2_index"]
        )
        result_df.loc[~cl_mask, "mods_p2"] = ""
        result_df.loc[~cl_mask, "mod_pos_p2"] = ""
        result_df.loc[~cl_mask, "mod_mass_p2"] = ""

        return result_df

    def _replicate_spectrum_info(self, result):
        """
        Return the spectrum info in a DataFrame once per every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        """
        return pd.concat([pd.DataFrame(
            {'scan_index': [result.spectrum.scan_index],
             'scan_number': [result.spectrum.scan_number],
             'retention_time': [result.spectrum.rt],
             'run_name': [result.spectrum.run_name],
             'peaklist_file': [result.spectrum.file_name],
             'source': [result.spectrum.source_path],
             'spectrum_mz': [result.spectrum.precursor_mz],
             'spectrum_charge': [result.spectrum.precursor_charge],
             # numpy and pandas treat missing values differently
             'precursor_intensity': [np.nan
                                     if result.spectrum.precursor_int is None
                                     else result.spectrum.precursor_int]})] * len(
            result.matches), ignore_index=True)

    def _crosslinker_info_to_dataframe(self, result, xl_names, xl_masses):
        """
        Return the crosslinker info in a DataFrame for every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        :param xl_names - (array) names of all crosslinker
        :param xl_masses - (array) masses of all crosslinker
        """
        return pd.DataFrame({
            'crosslinker_name': xl_names[result.matches['crosslinker_index']],
            'crosslinker_mass': xl_masses[result.matches['crosslinker_index']],
        })

    def _peptide_info_to_dataframe(self, result):
        """
        Return the peptide info in a DataFrame for every row in result.matches.

        :param result - (SpectrumResult) result for a single spectrum
        """
        return pd.DataFrame({
            'sequence_p1': np.char.decode(self.context.peptide_db.mod_pep_sequence(
                result.matches['p1_index']), encoding='ascii'),
            'base_sequence_p1': np.char.decode(self.context.peptide_db.unmod_pep_sequence(
                result.matches['p1_index']), encoding='ascii'),
            'sequence_p2': np.char.decode(self.context.peptide_db.mod_pep_sequence(
                result.matches['p2_index']), encoding='ascii'),
            'base_sequence_p2': np.char.decode(self.context.peptide_db.unmod_pep_sequence(
                result.matches['p2_index']), encoding='ascii'),
        })


class TsvResultWriter(ResultWriter):
    """Write results as tab-separated values."""

    def __init__(self, out_path, context, cache_size=50):
        """
        Initialise the tsv result writer.

        :param out_path: (str) where to write the result file.
        :param context: (SearchContext) the context of the search results to write.
        :param cache_size: (int) cache size for batched writing of results to file.
        """
        super().__init__(context)
        self.cache = []
        self.cache_size = cache_size
        self.file = open(out_path, "a")
        self._header_written = False

    def write(self, result):
        """
        Write the results to the TSV file (or to cache).

        Append result to tsv file. Write a header if it's the first result for this file.
        :param result: (tuple) result to write.
            (np.array) spectrum match results.
            (np.array) protein link sites.
        """
        self.cache.append(result)
        if len(self.cache) >= self.cache_size:
            self._write()

    def _write(self):
        """Write the results and clear the cache."""
        result = self._to_dataframe(self.cache)
        result = result[self.ordered_output_columns]
        result.to_csv(
            self.file,
            header=not self._header_written,
            sep="\t",
            index=False,
            na_rep="NaN",
        )
        self._header_written = True
        self.cache = []

    def close(self):
        """Write the remaining cached results and close the file."""
        if len(self.cache) > 0:
            self._write()
        self.file.close()


class MemoryResultWriter(ResultWriter):
    """Write results to a list in memory."""

    def __init__(self, context):
        """
        Initialise the memory result writer.

        :param context: (SearchContext) the context of the search results to write.
        """
        super().__init__(context)
        self._results = []
        self.context = context
        self._header_written = False

    def write(self, result):
        """
        Append result to self._results list.

        :param result: (np.array) result to write.
        """
        result = self._to_dataframe([result])
        result = result[self.ordered_output_columns]
        self._results.append(result)

    def close(self):
        """Close not needed when writing to memory."""
        pass

    def results(self):
        """Return results."""
        return self._results


class DummyResultWriter(ResultWriter):
    """Take results and do nothing."""

    def __init__(self, context):
        """Initialise the dummy writer."""
        super().__init__(context)

    def write(self, result):
        """Do nothing."""
        pass

    def close(self):
        """Do nothing."""
        pass


def convert_to_xispec(in_df, config):
    """
    Convert a result dataframe to xiSPEC csv format.

    :param in_df: (DataFrame) search result dataframe
    :param config: (Config) Search config (for ms2 tolerance and fragment ion types)
    :return: (DataFrame) results in xiSPEC csv format
    """
    col_mapping = {
        "sequence_p1": "PepSeq1",
        "sequence_p2": "PepSeq2",
        "link_pos_p1": "LinkPos1",
        "link_pos_p2": "LinkPos2",
        "protein_p1": "Protein1",
        "protein_p2": "Protein2",
        "decoy_p1": "Decoy1",
        "decoy_p2": "Decoy2",
        "match_score": "Score",
        "precursor_charge": "Charge",
        "crosslinker_mass": "CrossLinkerModMass",
        "precursor_mz": "ExpMz",
        "calc_mz": "CalcMz",
        "scan_index": "ScanId",
        "peaklist_file": "PeakListFileName",
    }
    # top ranking only
    out_df = in_df[in_df["top_ranking"]]
    # subset to necessary columns and rename
    out_df = out_df[col_mapping.keys()].rename(columns=col_mapping)

    # Decoy columns expect True/False
    out_df["Decoy1"] = out_df["Decoy1"].astype(bool)
    out_df["Decoy2"] = out_df["Decoy2"].astype(bool)

    # add fragment tolerance and ion types columns from config
    frag_tol = re.search(r"^([0-9.]+)\s?(ppm|Da)$", config.ms2_tol).groups()
    out_df["FragmentTolerance"] = f"{frag_tol[0]} {frag_tol[1]}"

    ion_types = ";".join(
        config.fragmentation.nterm_ions + config.fragmentation.cterm_ions
    )
    if config.fragmentation.add_precursor:
        ion_types += ";peptide"
    out_df["IonTypes"] = ion_types

    return out_df
