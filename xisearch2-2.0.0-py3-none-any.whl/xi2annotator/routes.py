from flask import request
from xi2annotator import bp
from xi2annotator.annotation import annotate_request


@bp.route('/xiAnnotator/annotate/FULL', methods=['POST'])
def annotate():
    if not request.is_json:
        return "Invalid JSON", 400
    # get the content of the json request
    content = request.get_json()

    return annotate_request(content)
