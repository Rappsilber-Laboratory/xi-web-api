"""
This module implements ways to retrieve alpha and beta candidates to match MS2 spectra.

In xiSEARCH the alpha candidates are peptides that match the preprocessed and linearized
MS2 spectrum based on linear fragments only. The beta candidates are retrieved for each
alpha candidate by mass only. This is followed by beta candidate scoring and full scoring
of the alpha-beta peptide pair.
"""

from xisearch2.crosslink import get_possible_link_sites
from xisearch2.fragment_peptides import fragment_crosslinked_peptide_pair, \
    fragment_linear_peptide, fragment_noncovalent_peptide_pair, \
    fragment_crosslinked_peptide_pair_minimal, \
    fragment_linear_peptide_minimal, fragment_noncovalent_peptide_pair_minimal
from xisearch2 import const, dtypes
import numpy as np


def get_alpha_candidates(spectrum, context):
    """
    Generate alpha peptide candidates for a spectrum.

    The alpha candidates are extracted based on matching linear fragments
    from the fragment_db available via the search context.

    :param spectrum: (Spectrum) the spectrum to match against
    :param context (SearchContext) Search context
    :return: unsorted alpha candidates
    :rtype: structured np.array
        peptide_index (np.intp): index into the peptide_db
        peptide_score (np.float64): score based on number and rarity of matching fragments
    """
    # Look up peptides matching peaks in this spectrum
    matches = context.fragment_db.lookup(spectrum.mz_values, context.config.ms2_atol,
                                         context.config.ms2_rtol)
    order = np.argsort(matches['id'])
    matches = matches[order]

    # The following np.unique call does several things in one step. The results are:
    #
    # - unique_peaks contains the unique indices of mz_array which matched at
    #   least one peptide.
    #
    # - peak_tags has the same length as matches, and contains the indices mapping
    #   each match to a unique peak.
    #
    # - fragment_counts contains, for each entry in unique_peaks, the number of
    #   fragments which matched that peak.
    #
    unique_peaks, peak_tags, fragment_counts = np.unique(matches['mass_index'],
                                                         return_inverse=True,
                                                         return_counts=True)

    # Similarly, after the following call:
    #
    # - unique_peptides contains the unique indices of the fragment DB peptides which
    #   matched at least one peak.
    #
    # - peptide_indices contains the indices of the first occurrence of each unique
    #   peptide in the matches array.
    #
    unique_peptides, peptide_indices = np.unique(matches['id'], return_index=True)

    # Allocate result array.
    result_dtype = [('peptide_index', np.intp), ('peptide_score', np.float64)]
    result = np.empty(len(unique_peptides), result_dtype)

    # Calculate peak scores for each unique peak.
    peak_scores = fragment_counts / context.fragment_db.num_fragments

    # Get peak scores associated with each match.
    match_scores = peak_scores[peak_tags]

    # Populate result
    result['peptide_index'] = unique_peptides
    result['peptide_score'] = np.multiply.reduceat(match_scores, peptide_indices)

    # invert scores (so larger is better - like other scores)
    result['peptide_score'] = - np.log(result['peptide_score'])

    return result


def get_ab_candidates(precursor_masses, alpha_pep_indices, context):
    """
    Generate alpha & beta peptide candidates for a spectrum, given alpha candidates.

    The beta candidates are extracted from the peptide database available via the
    search context. Only peptides matching the 'gap mass' of the precursor mass minus
    the alpha peptide mass and the crosslinker mass are extracted from the DB.
    A single mass or an ndarray of masses are accepted (i.e. for ximpa)

    :param precursor_masses: (float|ndarray) the precursor masses
    :param alpha_pep_indices: (int|ndarray) indices of alpha peptides in the DB
    :param context: (SearchContext) search context

    :return: array of candidates
    :rtype: numpy.ndarray
        ('alpha_pep_index', np.intp),
        ('beta_pep_index', np.intp),
        ('isotope_index', np.intp)
        ('crosslinker_index', np.int8)
    """
    config = context.config

    precursor_masses = np.atleast_1d(precursor_masses)
    alpha_pep_indices = np.atleast_1d(alpha_pep_indices)
    alpha_masses = context.peptide_db.peptide_mass(alpha_pep_indices)

    # Check if each alpha could be a linear match against each precursor
    linear_matches = np.isclose(
        alpha_masses.reshape(-1, 1),
        precursor_masses.reshape(1, -1),
        rtol=context.config.ms1_rtol,
        atol=context.config.ms2_atol)

    ln_mask = np.any(linear_matches, axis=1)

    # Create candidates for linear matches
    linear_candidates = np.empty(ln_mask.sum(), dtypes.ab_candidate)
    linear_candidates['alpha_pep_index'] = alpha_pep_indices[ln_mask]
    linear_candidates['beta_pep_index'] = -1
    linear_candidates['isotope_index'] = np.where(linear_matches[ln_mask])[1]
    linear_candidates['crosslinker_index'] = -1

    subtables = [linear_candidates]

    # create list of crosslinker index and mass tuples
    xl_parameters = [(i, xl.mass) for i, xl in enumerate(context.config.crosslinker)]
    if context.config.noncovalent_peptides:
        xl_parameters.append((-1, 0))

    # Create crosslinked candidates against each precursor
    for isotope_index, precursor_mass in enumerate(precursor_masses):

        # the tolerance for the beta-lookup is dependent on the precursor mass
        tolerance = config.ms1_rtol * precursor_mass + config.ms1_atol

        for xl_index, xl_mass in xl_parameters:

            # Generate array of possible beta masses
            gap_masses = precursor_mass - (alpha_masses[~ln_mask] + xl_mass)

            # Look up possible beta candidates based on mass.
            matches = context.peptide_db.lookup(gap_masses, relative_tolerance=0,
                                                absolute_tolerance=tolerance)

            # remove linear_only peptides
            matches = matches[~context.modified_peptides[matches['id']]['linear_only']]

            # Generate a-b candidate entries based on these matches.
            subtable = np.empty_like(matches, dtype=dtypes.ab_candidate)

            subtable['alpha_pep_index'] = alpha_pep_indices[~ln_mask][matches['mass_index']]
            subtable['beta_pep_index'] = matches['id']
            subtable['isotope_index'] = isotope_index
            subtable['crosslinker_index'] = xl_index

            subtables.append(subtable)

    return np.concatenate(subtables)


def get_beta_candidates(precursor_masses, alpha_pep_index, context):
    """
    Lookup all beta peptide candidates for a spectrum given a single alpha peptide.

    The beta candidates are extracted from the peptide database available via the
    search context. Only peptides matching  the 'gap mass' of the precursor mass minus
    the alpha peptide mass and the cross-linker mass are extracted from the db.
    A single mass or an ndarray of masses are accepted (i.e. for ximpa)

    :param precursor_masses: (float|ndarray) the precursor masss
    :param alpha_pep_index: (int) Index into the peptide DB for the alpha peptide
    :param context: (Config) search configuration

    :return: array of peptides
    :rtype: numpy.ndarray
        ('peptide_index', np.intp),
        ('isotope_index', np.intp)
        ('crosslinker_index', np.int8)
    """

    ab_candidates = get_ab_candidates(precursor_masses,
                                      np.array([alpha_pep_index]),
                                      context)

    beta_candidates = np.empty_like(ab_candidates, dtype=dtypes.beta_candidate)
    beta_candidates['peptide_index'] = ab_candidates['beta_pep_index']
    beta_candidates['isotope_index'] = ab_candidates['isotope_index']
    beta_candidates['crosslinker_index'] = ab_candidates['crosslinker_index']

    return beta_candidates


def ab_candidate_fragments(alpha_index, beta_index, cl_index, context):
    """
    Generate all singly charged, lossless fragments for an alpha/beta candidate.

    :param alpha_index: (int) index of the alpha peptide
    :param beta_index: (int) index of the beta peptide, -1 for linear alpha
    :param cl_index: (int) index of the crosslinker, -1 for linear / noncovalent
    :param context: (SearchContext) search context
    :return: (ndarray) fragments numpy array with mz, charge and ion_type
    """

    add_precursor = context.config.fragmentation.add_precursor

    # generate fragments for peptides without crosslink (linear and noncovalent)
    if cl_index == -1:
        # linear fragments for the alpha peptide
        if beta_index == -1:
            return fragment_linear_peptide(alpha_index, context=context,
                                           add_precursor=add_precursor)
        # noncovalent peptide pair fragments
        else:
            return fragment_noncovalent_peptide_pair(alpha_index, beta_index,
                                                     context=context, add_precursor=add_precursor)
    # generate fragments for crosslinked peptides
    else:
        crosslinker = context.config.crosslinker[cl_index]
        link_sites, sites_bonus = get_possible_link_sites(alpha_index, beta_index, crosslinker,
                                                          context)
        # return empty result if there are no possible crosslink sites on at least one peptide
        if link_sites[0].size == 0 or link_sites[1].size == 0:
            return np.array([], dtypes.fragments)
        # generate fragments for all possible link site combinations
        return fragment_crosslinked_peptide_pair(
            alpha_index, beta_index, link_sites[0], link_sites[1],
            crosslinker=crosslinker, context=context,
            add_precursor=add_precursor)


def ab_candidate_fragments_minimal(alpha_index, beta_index, cl_index, context):
    """
    Generate mz values and linearity for all singly charged, lossless fragments
    of an alpha/beta candidate.

    :param alpha_index: (int) index of the alpha peptide
    :param beta_index: (int) index of the beta peptide, -1 for linear alpha
    :param cl_index: (int) index of the crosslinker, -1 for linear / noncovalent
    :param context: (SearchContext) search context
    :return: (ndarray) mz values, (ndarray) linearity mask, (ndarray) stub masses
    """

    # generate fragments for peptides without crosslink (linear and noncovalent)
    if cl_index == -1:
        # linear fragments for the alpha peptide
        if beta_index == -1:
            return fragment_linear_peptide_minimal(alpha_index, context=context)
        # noncovalent peptide pair fragments
        else:
            return fragment_noncovalent_peptide_pair_minimal(alpha_index, beta_index,
                                                             context=context)
    # generate fragments for crosslinked peptides
    else:
        crosslinker = context.config.crosslinker[cl_index]
        link_sites, sites_bonus = get_possible_link_sites(alpha_index, beta_index, crosslinker,
                                                          context)
        # return empty result if there are no possible crosslink sites on at least one peptide
        if link_sites[0].size == 0 or link_sites[1].size == 0:
            return np.array([], float), np.array([], bool), np.array([], float)
        # generate fragments for all possible link site combinations
        return fragment_crosslinked_peptide_pair_minimal(
            alpha_index, beta_index, link_sites[0], link_sites[1],
            crosslinker=crosslinker, context=context)


def ab_candidate_score(spectrum, ab_candidates, context):
    """
    Calculate the candidate score for alpha-beta candidates.

    It generates all fragments for all possible link site combinations of the peptide pair and
    matches them to the deisotoped, denoised, decharged spectrum. Matched second peptide /
    crosslinker containing fragments get converted to their linear counterpart ions before
    lookup and scoring based on their rarity in the fragment_db.

    :param spectrum: (Spectrum) the spectrum to match against
    :param ab_candidates: (ndarray, dtypes.ab_candidate) alpha-beta candidates
    :param context: (SearchContext) search context
    :return: scores of the ab candidates
    :rtype: (np.ndarray)
    """
    config = context.config

    alpha_indices = ab_candidates['alpha_pep_index']
    beta_indices = ab_candidates['beta_pep_index']
    xl_indices = ab_candidates['crosslinker_index']

    alpha_masses = context.peptide_db.peptide_mass(alpha_indices)
    beta_masses = context.peptide_db.peptide_mass(beta_indices)
    crosslinker_masses = np.array([xl.mass for xl in context.config.crosslinker] + [np.nan])

    # linear only peptides are not in the fragment DB so we need to create a score offset to
    # account for that. Otherwise we could end up with 0 matches to a fragment in the DB and
    # therefore log(0) = infinite score for a match - which would be somewhat wrong
    score_offset = ((beta_indices == -1) & (context.modified_peptides[
        alpha_indices]['linear_only'])).view(np.uint8)

    # calculate linearisation masses
    neutral_precursor_masses = alpha_masses + beta_masses + crosslinker_masses[xl_indices]
    linearisation_masses = neutral_precursor_masses + 2 * const.PROTON_MASS

    fragment_mass_arrays = []
    linear_arrays = []
    stub_mass_arrays = []

    # get fragment masses and linearities for each candidate
    for i, (alpha_index, beta_index, beta_isotope_index, cl_index) in enumerate(ab_candidates):

        mz, linear, stubs = \
            ab_candidate_fragments_minimal(alpha_index, beta_index, cl_index, context)
        fragment_mass_arrays.append(mz)
        linear_arrays.append(linear)
        stub_mass_arrays.append(stubs)

    # combine results
    candidate_fragment_counts = np.array([len(a) for a in fragment_mass_arrays])
    candidate_ids = np.repeat(np.arange(len(ab_candidates)), candidate_fragment_counts)
    fragment_masses = np.concatenate(fragment_mass_arrays)
    linear_mask = np.concatenate(linear_arrays)
    stub_masses = np.concatenate(stub_mass_arrays)

    # match them against the spectrum ToDo: check for decharged spectrum
    matched_frag_indices, max_peak_indices, match_mz, num_direct = \
        spectrum.match_fragments(fragment_masses, charge=1,
                                 primary=np.ones(fragment_masses.size, dtype=bool),
                                 context=context)

    # filter to the fragments that matched the spectrum
    fragment_masses = fragment_masses[matched_frag_indices]
    linear_mask = linear_mask[matched_frag_indices]
    candidate_ids = candidate_ids[matched_frag_indices]
    stub_masses = stub_masses[matched_frag_indices]

    # linearise crosslinker containing fragments
    xl_mask = (xl_indices != -1)
    linearise_mask = xl_mask[candidate_ids] & ~linear_mask
    fragment_masses[linearise_mask] *= -1
    fragment_masses[linearise_mask] += linearisation_masses[candidate_ids[linearise_mask]]

    # adjust masses of crosslinker-stub containing fragments
    fragment_masses -= stub_masses

    # get the scores
    ab_scores = context.fragment_db.candidate_scores(
        len(ab_candidates),
        fragment_masses, candidate_ids, score_offset[candidate_ids],
        config.ms2_atol, config.ms2_rtol)

    # Fill in a score of NaN for unlinkable candidates with no fragments generated
    ab_scores[candidate_fragment_counts == 0] = np.nan

    return ab_scores


def hard_cap_candidates(table, score_name, hard_cap):
    """
    Cut the table down to max. size of hard_cap by score_name and sorts it.

    The function assumes higher scores are better.
    Removes all entries that have the same score as the `hard_cap`+1'th entry.
    :param table: (struct ndarray) table to filter
    :param score_name: (str) name of the score column to use
    :param hard_cap: (int) how many (non-unique) scores to return at most
    :return: sorted table with maximum size of hard_cap
    :rtype: struct ndarray
    """
    if table.size > hard_cap:
        # partition the table to -(hard_cap+1) (higher scores are better)
        hard_cap_indices = np.argpartition(table[score_name], -(hard_cap + 1))
        table = table[hard_cap_indices[-(hard_cap+1):]]
        # remove all scores that have the same score as hard_cap+1 score (now the first element)
        table = table[table[score_name] != table[0][score_name]]
    # sort the table
    table = np.sort(table, order=score_name)
    # return with highest score at top
    return table[::-1]


def base_sequence_rescore_alphas(alphas, context):
    """
    Re-score alpha candidates based on their base sequence.

    Assumes a sorted array as input
    :param alphas: (struct ndarray) table of sorted alpha candidates
    :param context: (Searcher) search context
    :return: base sequence score for alphas
    :rtype: float ndarray
    """
    # look up the sequence indices in the peptide_db
    base_seq_indices = context.peptide_db.peptides[alphas['peptide_index']]['sequence_index']
    # get the indices and inverse indices of unique base sequences
    _, indices, inv = np.unique(base_seq_indices, return_index=True, return_inverse=True)
    # create the scores for the unique base sequences
    unique_base_scores = alphas['peptide_score'][indices]
    # recreate original arr order by using the inverse indices
    base_scores = unique_base_scores[inv]

    return base_scores


def top_n_unique_scores(scores, top_n):
    """
    Get top_n indices of array and their corresponding ranks (1-based).

    Higher scores are better.
    :param scores: (ndarray) scores to filter
    :param top_n: (int) how many top unique scores to return
    :return: (indices ndarray) filtered and sorted indices of input ndarray
             (int ndarray) corresponding score ranks
    """
    sorted_indices = np.argsort(scores)
    sorted_scores = scores[sorted_indices]
    unique_scores, indices, ranks = np.unique(sorted_scores, return_index=True,
                                              return_inverse=True)
    if top_n >= unique_scores.size:
        top_score_indices = sorted_indices
        top_ranks = ranks
    else:
        # np.unique sorts ascending, but higher scores are better so:
        # get the index of the last score from the bottom of indices
        first_index = indices[-top_n]
        top_score_indices = sorted_indices[first_index:]
        top_ranks = ranks[first_index:]

    # ranks are the wrong way round - change this and convert to 1-based
    top_ranks = top_ranks.max(initial=0) - top_ranks + 1

    # return descending score table & ranks
    return top_score_indices[::-1], top_ranks[::-1]


def get_alpha_spectrum(base_candidate_spectrum, context):
    """
    Generate the linearised alpha-spectrum.

    In case there are several precursors to be considered a meta spectrum will be created that
    contains all unique peaks from each linearised spectrum

    :param base_candidate_spectrum: (Spectrum) isotope & charge reduced spectrum
    :param context: (Context) search context
    :return: (Spectrum) linearised alpha spectrum
    """
    # Linearise and denoise the base_candidate_spectrum
    linearized_spectrum = context.linearisation_filter.process(base_candidate_spectrum)
    alpha_spectrum = context.alpha_denoise_filter.process(linearized_spectrum)

    if context.config.isotope_error_ximpa > 0:
        precursor_mz = base_candidate_spectrum.precursor_mz
        # we use several precursor - meaning we need to linearize for each
        for _ in range(1, context.config.isotope_error_ximpa + 1):
            # modify spectrum precursor m/z by subtracting isotopic peak distance
            base_candidate_spectrum.precursor_mz -= \
                const.C12C13_MASS_DIFF / base_candidate_spectrum.precursor_charge

            # redo linearisation with updated precursor m/z
            mpa_linearized_spectrum = context.linearisation_filter.process(
                base_candidate_spectrum)

            # and noise filter
            mpa_alpha_spectrum = context.alpha_denoise_filter.process(mpa_linearized_spectrum)

            overlaps = np.isclose(alpha_spectrum.mz_values,
                                  mpa_alpha_spectrum.mz_values.reshape(-1, 1),
                                  rtol=context.config.ms2_rtol, atol=context.config.ms2_atol)

            # find new peaks
            new_peaks = np.where(np.all(np.invert(overlaps), axis=1))

            # transfer the new peaks
            alpha_spectrum.mz_values = np.append(alpha_spectrum.mz_values,
                                                 mpa_alpha_spectrum.mz_values[new_peaks])

            alpha_spectrum.int_values = np.append(alpha_spectrum.int_values,
                                                  mpa_alpha_spectrum.int_values[new_peaks])

        mz_order = np.argsort(alpha_spectrum.mz_values)
        alpha_spectrum.mz_values = alpha_spectrum.mz_values[mz_order]
        alpha_spectrum.int_values = alpha_spectrum.int_values[mz_order]

        # I modify the precursor mz for the each linearistation above. So it
        # needs to be restored to its original value
        base_candidate_spectrum.precursor_mz = precursor_mz

    return alpha_spectrum
