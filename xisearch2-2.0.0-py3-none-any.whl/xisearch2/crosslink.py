import numpy as np
from xisearch2.fragmentation import include_losses, spread_charges
from xisearch2 import dtypes
from xisearch2.cython import isin_set_double


def get_possible_link_sites(pep1_index, pep2_index, crosslinker, context):
    """
    Get all possible link sites between two peptides.

    :param pep1_index: (int) Index into the peptide DB for peptide1
    :param pep2_index: (int) Index into the peptide DB for peptide2
    :param crosslinker: (Crosslinker) the crosslinker involved
    :param context: (Searcher) Search context
    :return: possible link sites and bonus arrays
    :rtype: (tuple of ndarrays)
                ndarray of linksites on first peptide,
                ndarray of linksites on second peptide
            (tuple of ndarrays)
                ndarray of bonus weights on first peptide,
                ndarray of bonus weights on second peptide,

    """
    # get the amino acid specificity of the crosslinker
    cl = crosslinker
    aa_spec = cl.ord_aa_specificity

    # get the modification specificity of the crosslinker
    mod_spec = cl.mod_specificity
    mod_names = [''] + [mod.name for mod in context.config.modification.modifications]
    mod_codes = [[mod_names.index(mod) for mod in end] for end in mod_spec]

    # get the spec bonus array
    spec_bonus = cl.specificity_bonus

    # create arrays with amino acids of the peptides
    pep1_aa_arr = np.array(list(context.peptide_db.unmod_pep_sequence(pep1_index)))
    pep2_aa_arr = np.array(list(context.peptide_db.unmod_pep_sequence(pep2_index)))

    # get the peptides array form
    mod_pep1 = context.peptide_db.peptides[pep1_index]
    mod_pep2 = context.peptide_db.peptides[pep2_index]

    # get the modifications of the peptides (first two elements are n/c term modifications)
    pep1_mod_arr = mod_pep1['modifications'][2:pep1_aa_arr.size+2]
    pep2_mod_arr = mod_pep2['modifications'][2:pep2_aa_arr.size+2]

    # get the site_idx_table entry of the peptides (contains nterm and cterm information)
    pep1_site_info = context.get_site_info_for_mod_pep_index(pep1_index)
    pep2_site_info = context.get_site_info_for_mod_pep_index(pep2_index)

    # check for X (wildcard) in specificity array
    if 88 in aa_spec[0]:
        spec1_pep1_sites = np.repeat(True, pep1_aa_arr.size)
        spec1_pep2_sites = np.repeat(True, pep2_aa_arr.size)
        # ToDo: necessary to have weights for wildcard?
        x_index = aa_spec[0].index(88)
        spec1_pep1_bonus = np.repeat(spec_bonus[x_index], pep1_aa_arr.size)
        spec1_pep2_bonus = np.repeat(spec_bonus[x_index], pep2_aa_arr.size)
    else:
        aa_spec1 = np.array(aa_spec[0]).reshape(-1, 1)
        mod_spec1 = np.array(mod_codes[0]).reshape(-1, 1)
        bonus_spec1 = np.array(spec_bonus[0]).reshape(-1, 1)
        # match amino acids for pep1 with linker specificity 1
        aa_spec1_pep1_matches = pep1_aa_arr == aa_spec1
        # match modifications for pep1 with linker specificity 1
        mod_spec1_pep1_matches = pep1_mod_arr == mod_spec1
        # combine to get possible matches for pep1 with linker specificity 1
        spec1_pep1 = aa_spec1_pep1_matches & mod_spec1_pep1_matches
        spec1_pep1_sites = np.any(spec1_pep1, axis=0)
        spec1_pep1_bonus = np.sum(
            bonus_spec1[np.multiply(spec1_pep1, np.arange(spec1_pep1.shape[0]).reshape(-1, 1))].
            reshape(spec1_pep1.shape) * spec1_pep1, axis=0)

        # match amino acids for pep2 with linker specificity 1
        aa_spec1_pep2_matches = pep2_aa_arr == aa_spec1
        # match modifications for pep2 with linker specificity 1
        mod_spec1_pep2_matches = pep2_mod_arr == mod_spec1
        # combine to get possible matches for pep2 with linker specificity 1
        spec1_pep2 = aa_spec1_pep2_matches & mod_spec1_pep2_matches
        spec1_pep2_sites = np.any(spec1_pep2, axis=0)
        spec1_pep2_bonus = np.sum(
            bonus_spec1[np.multiply(spec1_pep2, np.arange(spec1_pep2.shape[0]).reshape(-1, 1))].
            reshape(spec1_pep2.shape) * spec1_pep2, axis=0)

        # adjust for protein terminal linkability
        if cl.nterm[0]:
            if pep1_site_info['nterm'] & (mod_pep1['modifications'][0] == 0):
                spec1_pep1_sites[0] = True
                spec1_pep1_bonus[0] += cl.nterm_bonus[0]
            if pep2_site_info['nterm'] & (mod_pep2['modifications'][0] == 0):
                spec1_pep2_sites[0] = True
                spec1_pep2_bonus[0] += cl.nterm_bonus[0]
        if cl.cterm[0]:
            if pep1_site_info['cterm'] & (mod_pep1['modifications'][1] == 0):
                spec1_pep1_sites[-1] = True
                spec1_pep1_bonus[-1] += cl.cterm_bonus[0]
            if pep2_site_info['cterm'] & (mod_pep2['modifications'][1] == 0):
                spec1_pep2_sites[-1] = True
                spec1_pep2_bonus[-1] += cl.cterm_bonus[0]

    # if the crosslinker is homobifunctional then combine the peptide sites
    if cl.homobifunctional:
        possible_sites = spec1_pep1_sites.reshape(-1, 1) & spec1_pep2_sites
    # if the crosslinker is heterobifunctional check the second specificity
    else:
        aa_spec2 = np.array(aa_spec[1]).reshape(-1, 1)
        mod_spec2 = np.array(mod_codes[1]).reshape(-1, 1)
        # check for X (wildcard) in specificity array
        if 88 in aa_spec2:
            spec2_pep1_sites = np.repeat(True, pep1_aa_arr.size)
            spec2_pep2_sites = np.repeat(True, pep2_aa_arr.size)
        else:
            # match amino acids for pep1 with linker specificity 2
            aa_spec2_pep1_matches = pep1_aa_arr == aa_spec2
            # match modifications for pep1 with linker specificity 2
            mod_spec2_pep1_matches = pep1_mod_arr == mod_spec2
            # combine to get possible matches for pep1 with linker specificity 2
            spec2_pep1_sites = np.any(aa_spec2_pep1_matches & mod_spec2_pep1_matches, 0)

            # match amino acids for pep2 with linker specificity 2
            aa_spec2_pep2_matches = pep2_aa_arr == aa_spec2
            # match modifications for pep1 with linker specificity 2
            mod_spec2_pep2_matches = pep2_mod_arr == mod_spec2
            # combine to get possible matches for pep2 with linker specificity 2
            spec2_pep2_sites = np.any(aa_spec2_pep2_matches & mod_spec2_pep2_matches, 0)

            # adjust for protein terminal linkability
            if cl.nterm[1] & pep1_site_info['nterm'] & (mod_pep1['modifications'][0] == 0):
                spec2_pep1_sites[0] = True
            if cl.cterm[1] & pep1_site_info['cterm'] & (mod_pep1['modifications'][1] == 0):
                spec2_pep1_sites[-1] = True
            if cl.nterm[1] & pep2_site_info['nterm'] & (mod_pep2['modifications'][0] == 0):
                spec2_pep2_sites[0] = True
            if cl.cterm[1] & pep2_site_info['cterm'] & (mod_pep2['modifications'][1] == 0):
                spec2_pep2_sites[-1] = True

        possible_sites1 = spec1_pep1_sites.reshape(-1, 1) & spec2_pep2_sites
        possible_sites2 = spec2_pep1_sites.reshape(-1, 1) & spec1_pep2_sites
        # I can just "or" the two possible sets of link combinations to get the final set
        possible_sites = np.logical_or(possible_sites1, possible_sites2)

    # adjust for blocked amino acids
    if pep1_site_info['nterm_aa_block']:
        possible_sites[0, :] = False
    if pep1_site_info['cterm_aa_block']:
        possible_sites[-1, :] = False
    if pep2_site_info['nterm_aa_block']:
        possible_sites[:, 0] = False
    if pep2_site_info['cterm_aa_block']:
        possible_sites[:, -1] = False
    possible_sites = np.where(possible_sites)

    if cl.homobifunctional:
        sites_bonus = (spec1_pep1_bonus[possible_sites[0]],
                       spec1_pep2_bonus[possible_sites[1]])
    else:
        # ToDo: change this once heterobifunctional bonus is supported
        # set bonus to 0 for all sites for now
        sites_bonus = tuple([[0]*len(n) for n in possible_sites])

    return possible_sites, sites_bonus


def find_link_site(alpha_beta_index, spectrum, pep1_index, pep2_index, cl_index, context,
                   basic_fragments):
    """
    Find the best matching link-site combination for given peptides and spectrum.

    To do so it currently runs the spectrum annotation for each possible link-site combination and
    assigns a single score to each of them. The score is based on the amount of explained intensity
     - normalised so that the sum of all scores is 1.
    :param spectrum: (Spectrum) the spectrum to match
    :param pep1_index: (int) Index into the peptide DB for peptide 1
    :param pep2_index: (int) Index into the peptide DB for peptide 2
    :param cl_index: (int) Index of the crosslinker in the config
    :param context (Searcher) search context
    :param basic_fragments all basic fragments (e.g. b/y) as singly charged ions
    :param alpha_beta_index: references that this is for the nth match to the spectrum
    :return: Link-sites with scores and annotations. Results are sorted by score (best to worst)
    :rtype: structured np.array
        alpha_beta_index: passed through alpha_beta_index parameter
        link1 (np.uint8): 0-based position of the crosslinker site for peptide 1
        link2 (np.uint8): 0-based position of the crosslinker site for peptide 2
        score (np.float32): score for this link-site combination
        annotation: (np.object): annotation table for this link-site combination
    """
    fragments = include_losses(basic_fragments, [pep1_index, pep2_index], context)
    fragments = spread_charges(fragments, context, spectrum.precursor_charge,
                               context.config.fragmentation.max_linear_fragment_charge,
                               context.config.fragmentation.min_crosslinked_fragment_charge)

    # check for linear or noncovalent peptides
    if cl_index == -1:
        annotation_table = spectrum.annotate_spectrum(fragments, context)
        link_record = [(alpha_beta_index, -1, -1, 1, annotation_table)]
    else:
        cl = context.config.crosslinker[cl_index]
        # get the possible linkage sites
        possible_sites, sites_bonus = get_possible_link_sites(pep1_index, pep2_index, cl, context)
        link_pos1 = possible_sites[0]
        link_pos2 = possible_sites[1]

        # return an empty array if there are no possible link sites for the two peptides
        if link_pos1.size == 0 or link_pos2.size == 0:
            return np.array([])

        pep1_len = context.modified_peptides_aa_lengths[pep1_index]
        pep2_len = context.modified_peptides_aa_lengths[pep2_index]

        # annotate spectrum with all
        annotation_table = spectrum.annotate_spectrum(fragments, context)

        # shared filter
        mask_pep1 = (annotation_table["pep_id"] == 1)
        mask_pep2 = (annotation_table["pep_id"] == 2)
        mask_nterm = (annotation_table["term"] == b'n')
        mask_cterm = (annotation_table["term"] == b'c')
        mask_stub = annotation_table["stub"] != b''
        mask_xl = (~annotation_table["LN"]) | mask_stub
        mask_l = ~mask_xl

        # combined filter
        mask_pep1_xl = mask_pep1 & mask_xl
        mask_pep2_xl = mask_pep2 & mask_xl
        mask_pep1_l = mask_pep1 & mask_l
        mask_pep2_l = mask_pep2 & mask_l
        mask_pep1_xl_n = mask_pep1_xl & mask_nterm
        mask_pep2_xl_n = mask_pep2_xl & mask_nterm
        mask_pep1_xl_c = mask_pep1_xl & mask_cterm
        mask_pep2_xl_c = mask_pep2_xl & mask_cterm
        mask_pep1_l_n = mask_pep1_l & mask_nterm
        mask_pep2_l_n = mask_pep2_l & mask_nterm
        mask_pep1_l_c = mask_pep1_l & mask_cterm
        mask_pep2_l_c = mask_pep2_l & mask_cterm

        # get base peak intensity for bonus calculation
        base_peak_int = spectrum.int_values.max()

        link_record = []
        # for each link-combinations find the annotations that do not fit
        for link1, link2, bonus1, bonus2 in zip(possible_sites[0], possible_sites[1],
                                                sites_bonus[0], sites_bonus[1]):
            # peptide 1 n-terminal  xl frags misassigned
            pep1_mask_n_xl = (mask_pep1_xl_n & (annotation_table["idx"] <= link1))
            # peptide 1 c-terminal  xl frags misassigned
            pep1_mask_c_xl = (mask_pep1_xl_c & (annotation_table["idx"] < (pep1_len - link1)))

            # peptide 1 n-terminal  linear frags misassigned
            pep1_mask_n_ln = (mask_pep1_l_n & (annotation_table["idx"] > link1))

            # peptide 1 c-terminal  linear frags misassigned
            pep1_mask_c_ln = (mask_pep1_l_c & (annotation_table["idx"] >= (pep1_len - link1)))

            # peptide 2 n-terminal  xl frags misassigned
            pep2_mask_n_xl = (mask_pep2_xl_n & (annotation_table["idx"] <= link2))
            # peptide 2 c-terminal  xl frags misassigned
            pep2_mask_c_xl = (mask_pep2_xl_c & (annotation_table["idx"] < (pep2_len - link2)))

            # peptide 2 n-terminal  linear frags misassigned
            pep2_mask_n_ln = (mask_pep2_l_n & (annotation_table["idx"] > link2))

            # peptide 2 c-terminal  linear frags misassigned
            pep2_mask_c_ln = (mask_pep2_l_c & (annotation_table["idx"] >= (pep2_len - link2)))

            # join every condition up
            miss_assigned = \
                pep1_mask_c_xl | pep1_mask_n_xl | pep1_mask_c_ln | pep1_mask_n_ln | \
                pep2_mask_c_xl | pep2_mask_n_xl | pep2_mask_c_ln | pep2_mask_n_ln

            # everything that fits to the link site
            annotation_fit = annotation_table[~miss_assigned]

            # primary (no neutral-loss) fragments that fit
            annotation_fit_primary = annotation_fit[annotation_fit["nlosses"] == 0]

            # get the mz and index for primary fragment ions
            fit_primary_mz, fit_primary_mz_idx = np.unique(annotation_fit_primary["peak_mz"],
                                                           return_index=True)

            # get neutral-loss ions that don't fit - but only if the peak is not already explained
            # by a fitting primary ion
            annotation_fit_loss = annotation_fit[
                annotation_fit["nlosses"] > 0 & ~isin_set_double(annotation_fit["peak_mz"],
                                                                 fit_primary_mz)]

            # sort by 'nlosses' otherwise extra annotation with higher nlosses can decrease score
            annotation_fit_loss.sort(order="nlosses")

            # get the first index for each peak matched loss only
            fit_loss_mz, fit_loss_mz_idx = np.unique(annotation_fit_loss["peak_mz"],
                                                     return_index=True)

            # intensity of non-loss peak-matches is count to 100%
            nlscore = sum(annotation_fit_primary["peak_int"][fit_primary_mz_idx])

            # intensity of loss peak-matches are only counted up to 10%, divided by the smallest
            # nlosses annotation for that peak
            lscore = sum(annotation_fit_loss["peak_int"][fit_loss_mz_idx]
                         / annotation_fit_loss["nlosses"][fit_loss_mz_idx]
                         / 10)

            bonus = base_peak_int * (bonus1 + bonus2)
            score = nlscore + lscore + bonus

            link_record.append((alpha_beta_index, link1, link2, score, annotation_fit))

    # convert to numpy array
    link_array = np.array(link_record, dtype=dtypes.link_site_annotations)

    # ignore divide by invalid value -> sum = 0 (no matches) will be filtered out later
    with np.errstate(invalid='ignore'):
        # normalize the scores, so that the sum of scores equals to 1
        link_array["score"] = link_array["score"] / np.sum(link_array["score"])

    # sort by:
    #   1. score desc,
    #   2. link site from the alphabetically smaller unmodified sequence desc
    #   3. link site from the alphabetically larger unmodified sequence desc
    seq1_idx = context.peptide_db.peptides[pep1_index]['sequence_index']
    seq2_idx = context.peptide_db.peptides[pep2_index]['sequence_index']
    if seq1_idx <= seq2_idx:
        sorted_indices = np.argsort(link_array[['score', 'link1', 'link2']])[::-1]
    else:
        sorted_indices = np.argsort(link_array[['score', 'link2', 'link1']])[::-1]

    return link_array[sorted_indices]
