"""This module handles FASTA files and creates target/decoy databases."""

from pyteomics import fasta
import numpy as np
import re
import hashlib
from xisearch2.proteindecoy import get_decoy_mode


class FastaReader(object):
    """Provide access to .FASTA files with general API."""

    def __init__(self, config):
        """
        Initialise the FastaReader.

        loaded_fasta: stores a list with loaded entries of a specified .fasta file
        arr_fasta: stores a numpy array of the protein sequences with the parsed information from
        the header. Use `reformat_to_array` first.
        :param config: (Config) Search configuration
        """
        self.config = config
        self._re_desc = re.compile(config.fasta.re_desc)
        self._re_name = re.compile(config.fasta.re_name)
        self._re_accession = re.compile(config.fasta.re_accession)

        self.loaded_fasta = None
        self.arr_fasta = None

    def load_file(self, fasta_files):
        """
        Load one or more FASTA files.

        Uses pyteomics fasta parser to read in .fasta.
        Each fasta entry is a 'Protein' object.
        :param fasta_files: (str | list of str) paths to FASTA files
        """
        self.loaded_fasta = []
        if type(fasta_files) != list:
            fasta_files = [fasta_files]

        for fasta_file in fasta_files:
            with open(fasta_file, "r") as f:
                self.loaded_fasta += [entry for entry in fasta.read(f)]

    def reformat_to_array(self):
        """Reformat the pyteomics' Protein objects in the loaded_fasta list to a numpy array."""
        # save parsed data to lists first for dtype length determination
        sequences = []
        accessions = []
        names = []
        descriptions = []
        headers = []

        for entry in self.loaded_fasta:
            # set sequence
            sequences.append(entry.sequence.encode('ascii'))

            # set the fasta header
            headers.append(entry.description)

            # try to match the protein accession
            accession_match = re.search(self._re_accession, entry.description)
            try:
                accessions.append(accession_match.group(1))
            # fallback to the entry description
            except AttributeError:
                accessions.append(entry.description)

            # try to match the protein name
            name_match = re.search(self._re_name, entry.description)
            try:
                names.append(name_match.group(1))
            # fallback to empty string
            except AttributeError:
                names.append('')

            # try to match the protein description
            desc_match = re.search(self._re_desc, entry.description)
            try:
                descriptions.append(desc_match.group(1))
            # fallback to the entry description
            except AttributeError:
                descriptions.append(entry.description)

            # ToDo: ability to parse decoy from fasta

        # create data types from max str lengths (accounting for decoy prefixes)
        dtypes = [('sequence', '<S%d' % (max([len(s) for s in sequences]))),
                  # header len +15 for 'DECOY_PERMUTED:'
                  ('header', '<U%d' % (max([len(s) for s in headers]) + 15)),
                  ('name', '<U%d' % (max([len(s) for s in names]) + len(self.config.decoy.prefix))),
                  ('accession', '<U%d' % (max([len(s) for s in accessions])
                                          + len(self.config.decoy.prefix))),
                  ('description', '<U%d' % (max([len(s) for s in descriptions + ['decoy']]))),
                  ('decoy', np.bool_)]

        self.arr_fasta = np.empty(len(self.loaded_fasta), dtype=dtypes)

        self.arr_fasta['sequence'] = sequences
        self.arr_fasta['accession'] = accessions
        self.arr_fasta['name'] = names
        self.arr_fasta['description'] = descriptions
        self.arr_fasta['header'] = headers
        self.arr_fasta['decoy'] = False

    def add_decoys(self):
        """
        Generate and add decoys to the self.arr_fasta.

        ToDo: this is not modification aware if the input fasta file contains modifications their
            AA position will most probably not be conserved
        """
        decoy_fnc = get_decoy_mode(self.config)
        if decoy_fnc is None:
            return
        prefix = self.config.decoy.prefix

        # copy target proteins
        decoys = np.copy(self.arr_fasta)

        # create new sequences
        decoy_fnc = np.vectorize(decoy_fnc)
        decoys['sequence'] = decoy_fnc(decoys['sequence'])

        # prepend accessions with the prefix
        decoys['accession'] = np.char.add(prefix, decoys['accession'])

        # prepend names with the prefix
        decoys['name'] = np.char.add(prefix, decoys['name'])

        # replace descriptions with 'decoy'
        decoys['description'] = 'decoy'

        # prepend header with 'DECOY:'
        decoys['header'] = np.char.add('DECOY:', decoys['header'])

        decoys['decoy'] = True

        self.arr_fasta = np.concatenate([self.arr_fasta, decoys])

    def hash(self):
        """
        Create a hash of the loaded FASTA file(s).

        :return: hash of the protein ndarray
        """
        arr_view = self.arr_fasta.view()
        return hash(tuple(hashlib.sha1(arr_view).digest()))
