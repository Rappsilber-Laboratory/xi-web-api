"""Module for load testing the memory consumption and performance of xiSEARCH2."""

from xisearch2.synthetic_spectra import create_synthetic_load_test_mgf
from xisearch2.config import Config, ConfigReader, Crosslinker, IsotopeDetectorConfig, \
    ModificationConfig, Enzyme, DigestionConfig, FragmentationConfig, Loss
import os


# define some modifications for the load test
carbamidomethylation = {'name': 'cm', 'specificity': ['C'], 'type': 'fixed',
                        'composition': 'C2H3N1O1'}
oxidation = {'name': 'ox', 'specificity': ['M'], 'type': 'variable', 'composition': 'O1'}
bs3oh = {'name': 'bs3oh', 'specificity': ['K'], 'type': 'variable', 'composition': 'C8H12O3'}
bs3nh2 = {'name': 'bs3nh2', 'specificity': ['K'], 'type': 'variable', 'composition': 'C8H13N1O2'}
modifications = [carbamidomethylation, oxidation, bs3oh, bs3nh2]

# load_test_config definition
load_test_config = Config(digestion=DigestionConfig(enzymes=[Enzyme.trypsin],
                                                    missed_cleavages=0,
                                                    min_peptide_length=3),
                          ms1_tol='5ppm',
                          ms2_tol='15ppm',
                          crosslinker=[Crosslinker.BS3],
                          isotope_config=IsotopeDetectorConfig(),
                          modification=ModificationConfig(modifications=modifications),
                          fragmentation=FragmentationConfig(losses=[
                              Loss(name='H2O', composition="H2O1",
                                   specificity=['S', 'T', 'E', 'D',
                                                'cterm']),
                              Loss(name='NH3', composition="N1H3",
                                   specificity=['R', 'K', 'N', 'Q',
                                                'nterm'])
                          ]),
                          )

examples = [('mycoplasma', 687, 'uniprot-mitochondrion_human.FASTA'),
            ('mitochondrion', 1103, 'uniprot-proteome_myco.FASTA')]


class LoadTest:
    """A synthetic spectra load test case for the search pipeline."""

    def __init__(self, cache, n_spectra=10000, max_charge=6, isotopes=0):
        """
        Initialise the LoadTest.

        :param cache: (Cache) cache to use
        :param n_spectra: (int) number of spectra used
        :param max_charge: (int) maximum charge state of spectra used
        :param isotopes: (int) number of isotopes to generate
        """
        self.cache = cache
        self.n_spectra = n_spectra
        self.max_charge = max_charge
        self.isotopes = isotopes
        self.mgf_cache = None
        self.mgf = None

    def setup(self, context):
        """Set up the LoadTest."""
        mgf_hash = hash((context.modified_peptides_cache.hash,
                         self.n_spectra,
                         self.max_charge,
                         self.isotopes))
        self.mgf_cache = self.cache.item('spectra', 0, mgf_hash, extension='.mgf')
        if not self.mgf_cache.exists:
            create_synthetic_load_test_mgf(peptides=context.peptide_db.peptides,
                                           filename=self.mgf_cache.save_filename,
                                           context=context, n_spectra=self.n_spectra,
                                           max_charge=self.max_charge, isotopes=self.isotopes)
            self.mgf_cache.validate()
        self.mgf = self.mgf_cache.load_filename


class RealDataLoadTest:
    """A real data load test case for the search pipeline."""

    test_cases = ['Ecoli-S', 'Ecoli-L', 'HSA-S', 'HSA-L', 'MITO-L']
    load_test_dir = os.path.join(os.path.dirname(__file__), '../tests/fixtures/load_test/')

    def __init__(self, case):
        """
        Initialise the RealDataLoadTest.

        :param case: (str) Which load test to run. Valid options are:
            Ecoli-S: 50 spectra of an Ecoli-BS3 dataset 5% PSM level FDR (shuffled randomly)
                10 good quality crosslinked spectra (top hits),
                20 medium quality crosslinked spectra (11 < xi1 score < 13) (internal),
                10 bad quality crosslinked spectra (xi1 score < 5) (internal),
                10 good linear spectra (top hits)
            Ecoli-L: 500 spectra of an Ecoli-BS3 dataset 5% PSM level FDR
                100 good quality crosslinked spectra (top hits),
                200 medium quality crosslinked spectra (11 < xi1 score < 13) (internal),
                100 bad quality spectra (xi1 score < 5) (internal),
                100 good linear spectra (top hits)
            HSA-S: 50 spectra of an HSA-SDA dataset 5% PSM level FDR
                10 good quality crosslinked spectra (top hits),
                20 medium quality crosslinked spectra (bottom hits),
                10 bad quality spectra (from an Ecoli dataset),
                10 good linear spectra (top hits)
            HSA-L: 500 spectra of an HSA-SDA dataset 5% PSM level FDR
                100 good quality crosslinked spectra (top hits),
                200 medium quality crosslinked spectra (bottom hits),
                100 bad quality spectra (from an Ecoli dataset),
                100 good linear spectra (top hits)
            MITO-L: 500 random spectra of a Mitochondria-DSSO dataset
        """
        if case not in self.test_cases:
            raise TypeError('Unsupported real data load test case!\nSupported are: '
                            + ', '.join(self.test_cases))
        self.case = case
        self.mgf = None

        # E. coli
        if self.case.startswith('Ecoli'):
            self.config = ConfigReader.load_file(
                os.path.join(self.load_test_dir, '3_ecoli_BS3_LS_xi2_config.json'))
            self.fasta = os.path.join(self.load_test_dir, '3_4_Ecoli_LS_ID2_2up_1E5.fasta')
        # HSA
        elif self.case.startswith('HSA'):
            self.config = ConfigReader.load_file(
                os.path.join(self.load_test_dir, '1_HSA_SDA_AB_xi2_config.json'))
            self.fasta = os.path.join(self.load_test_dir, '1_P02768.fasta')
        elif self.case.startswith('MITO'):
            self.config = ConfigReader.load_file(
                os.path.join(self.load_test_dir, '2_MITO_config.json'))
            self.fasta = os.path.join(self.load_test_dir, '2_MITO.fasta')

    def setup(self, _):
        """Set up the LoadTest."""
        if self.case == 'Ecoli-S':
            self.mgf = os.path.join(self.load_test_dir, '3_ecoli_BS3_LS_load_test_small.mgf')
        elif self.case == 'Ecoli-L':
            self.mgf = os.path.join(self.load_test_dir, '3_ecoli_BS3_LS_load_test_large.mgf')
        elif self.case == 'HSA-S':
            self.mgf = os.path.join(self.load_test_dir, '1_HSA_SDA_AB_load_test_small.mgf')
        elif self.case == 'HSA-L':
            self.mgf = os.path.join(self.load_test_dir, '1_HSA_SDA_AB_load_test_large.mgf')
        elif self.case == 'MITO-L':
            self.mgf = os.path.join(self.load_test_dir, '2_MITO_L.mgf')
