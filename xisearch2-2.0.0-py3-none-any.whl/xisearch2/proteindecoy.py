"""Module for protein-based decoy generation."""
import random
from abc import ABC, abstractmethod
import re
import numpy as np
from xisearch2 import const
from .xi_logging import log, ProgressBar
from itertools import permutations
from xisearch2.cython import num_lexico_permutation


def permutate_decoy_sequence(context):
    """
    Permutate decoy sequences so that there are no decoys that have the same sequence as targets.

    This updates context.fixed_mod_peptide_sequences, and context.sites and also the
    context.proteins (adding new proteins for permuted sequences). The newly created
    proteins are returned so they can be saved to cache.

    At the moment decoy peptides containing terminal modifications that also exist as target
    peptides will not be permuted but just discarded.

    :param context: (SearchContext) Search context
    :return: Newly created proteins from permuted sequences
    """
    # get decoy protein ids
    decoy_protein_ids = np.where(context.proteins['decoy'])
    # stop if there are no decoys
    if decoy_protein_ids[0].size == 0:
        return np.array([], dtype=context.proteins.dtype)

    # convert peptide sequences to isobaric sequences
    iso_seqs = np.char.replace(context.fixed_mod_peptide_sequences, b'I', b'L')
    # get the unique isobaric sequences, their indices, inverse and counts array
    unique_perm_iso_seq, iso_idx, iso_inv, iso_count = np.unique(
        iso_seqs, return_index=True, return_inverse=True, return_counts=True)

    # Calculate the number of permutations of each isobaric amino acid composition already present
    # reorder amino acids of each peptide alphabetically
    unique_perm_iso_seq.view(np.uint8).reshape(-1, unique_perm_iso_seq.dtype.itemsize)[:, ::].sort()
    # get unique alphabetized sequences, inverse and counts array
    unique_alphabet_seqs, unique_alphabet_inv, unique_alphabet_counts = np.unique(
        unique_perm_iso_seq, return_inverse=True, return_counts=True)

    # get target and decoy peptides that have the same isobaric sequence
    decoy_mask = np.isin(context.sites['protein_id'], decoy_protein_ids)
    decoy_sites = context.sites[decoy_mask]
    target_sites = context.sites[~decoy_mask]
    # to check for same isobaric sequences we check for overlap in iso_pep_ids
    iso_pep_ids = np.repeat(iso_idx, iso_count)
    same_iso_pep_ids = np.intersect1d(iso_pep_ids[decoy_sites['peptide_id']],
                                      iso_pep_ids[target_sites['peptide_id']])
    # no point in continuing if there are none
    if same_iso_pep_ids.size == 0:
        return np.array([], dtype=context.proteins.dtype)
    # get the pep_ids that have same isobaric sequences
    same_iso_mask = np.any(np.equal(same_iso_pep_ids,
                           iso_pep_ids[decoy_sites['peptide_id']].reshape(-1, 1)), axis=1)
    same_pep_ids = np.unique(decoy_sites['peptide_id'][same_iso_mask])

    # get the indices into the alphabetized versions for checking permutation count
    unique_same_iso_alphabet_idx, same_iso_alphabet_inv = np.unique(
        unique_alphabet_inv[iso_inv[same_pep_ids]], return_inverse=True)
    # get corresponding sequences and counts
    same_iso_unique_alphabet_seqs = unique_alphabet_seqs[unique_same_iso_alphabet_idx]
    same_iso_unique_alphabet_counts = unique_alphabet_counts[unique_same_iso_alphabet_idx]
    # remove modifications from the sequences and transform uint8
    same_iso_nomod_unique_alphabet_seqs = np.array(
        [re.sub(b'[^A-Z]', b'', s) for s in same_iso_unique_alphabet_seqs])
    same_iso_nomod_unique_alphabet_seqs = same_iso_nomod_unique_alphabet_seqs.view(
        np.uint8).reshape(len(same_iso_unique_alphabet_seqs), -1)
    # calculate the maximum number of lexicographical permutations
    max_permutations = num_lexico_permutation(same_iso_nomod_unique_alphabet_seqs)
    # calculate permutations left array
    permutations_left = max_permutations - same_iso_unique_alphabet_counts

    # set the permutations_left to 0 for peptides with terminal modifications
    # Note: Permuting terminal modified peptides is more complicated and the current way of
    #   generating the unique_alphabet_seqs can not handle c and n term modifications consisting of
    #   the same characters.
    # get peptide ids that have terminal modifications (45 is '-' in uint8 view)
    term_mod_pep_ids = np.where(np.any(context.fixed_mod_peptide_sequences.view(np.uint8).reshape(
        -1, context.fixed_mod_peptide_sequences.dtype.itemsize) == 45, axis=1))[0]
    permutations_left[same_iso_alphabet_inv[term_mod_pep_ids]] = 0

    # sequences that need to be permuted
    same_seq = context.fixed_mod_peptide_sequences[same_pep_ids]
    # convert to lists of modified amino acids
    same_seq = [re.findall(const.MODIFIED_AA_PATTERN, s) for s in same_seq]

    # create the permutation generators
    permutations_list = np.array([permutations(s) for s in same_seq])
    # first elements from generators are the same_seq so skip these
    for p in permutations_list:
        next(p)
    # create an empty new sequence array that we're going to fill with permuted sequences
    n_seq = len(same_seq)
    new_perm_seqs = np.zeros(n_seq, dtype=context.fixed_mod_peptide_sequences.dtype)
    # initialise redo_idx
    redo_idx = np.arange(n_seq)
    # loop over permutations until we have no duplicates
    bar = ProgressBar("Permuting {} decoy sequences".format(n_seq), n_seq)
    while True:
        # remove those without permutations left from redo_idx
        no_perm_left_mask = permutations_left[same_iso_alphabet_inv[redo_idx]] <= 0
        redo_idx = redo_idx[~no_perm_left_mask]
        # get next permutations
        perm_seq = [list(next(p)) for p in permutations_list[redo_idx]]
        # turn into np.array
        perm_seq = np.array([b''.join(s) for s in perm_seq],
                            dtype=context.fixed_mod_peptide_sequences.dtype)

        # create isobaric versions to check for duplicates:
        perm_iso_seq = np.char.replace(perm_seq, b'I', b'L')
        # 1. check if any of the permuted sequences is an isobaric overlap with another
        unique_perm_iso_seq, perm_iso_idx = np.unique(perm_iso_seq, return_index=True)
        # 2. check against fixed_mod_peptide_sequences (iso_seqs)
        redo_mask1 = np.isin(unique_perm_iso_seq, iso_seqs)
        # 3. check against previously generated permutations (previous loops)
        new_iso_seq = np.char.replace(new_perm_seqs, b'I', b'L')
        redo_mask2 = np.isin(unique_perm_iso_seq, new_iso_seq)

        redo_mask = redo_mask1 | redo_mask2
        fill_idx = redo_idx[perm_iso_idx[~redo_mask]]
        redo_idx = np.setxor1d(redo_idx, fill_idx)
        if len(fill_idx) > 0:
            new_perm_seqs[fill_idx] = perm_seq[perm_iso_idx[~redo_mask]]
            # get the unique count of their alphabetized versions
            unique_fill_idx, fill_count = np.unique(same_iso_alphabet_inv[fill_idx],
                                                    return_counts=True)
            # reduce permutations left by fill_count
            permutations_left[unique_fill_idx] -= fill_count
            bar.next(len(fill_idx))
        if len(redo_idx) == 0:
            break
    bar.finish()

    # get the successfully permuted pep_ids
    perm_mask = new_perm_seqs != b''
    perm_idx = np.where(perm_mask)[0]
    perm_pep_ids = same_pep_ids[perm_idx]

    # remove decoy sites referring to peptides that have no possible permutation
    no_perm_idx = np.where(~perm_mask)[0]
    no_perm_pep_ids = same_pep_ids[no_perm_idx]
    no_perm_remove_mask = np.isin(context.sites['peptide_id'], no_perm_pep_ids)
    no_perm_decoy_sites_idx = np.where(no_perm_remove_mask & decoy_mask)[0]
    context.sites = np.delete(context.sites, no_perm_decoy_sites_idx)
    new_perm_seqs = np.delete(new_perm_seqs, no_perm_idx)

    # Report total number of decoys removed
    log(f'Permuted {len(new_perm_seqs)} decoy sequences that matched (isobaric) target sequences')
    n_decoy_sites_removed = no_perm_decoy_sites_idx.size
    n_pep_ids_removed = len(no_perm_pep_ids)
    log('Removed {} decoy sites ({:.1%}) from {} unique sequences ({:.1%}) because they have no '
        'possible sequence permutation solution'.format(
            n_decoy_sites_removed,
            n_decoy_sites_removed / decoy_sites.size,
            n_pep_ids_removed,
            n_pep_ids_removed / context.fixed_mod_peptide_sequences.size))

    # get indices of the permuted sites to update later with new prot and pep ids
    decoy_mask = np.isin(context.sites['protein_id'], decoy_protein_ids)
    perm_mask = np.isin(context.sites['peptide_id'], perm_pep_ids)
    perm_site_idx = np.where(decoy_mask & perm_mask)[0]
    perm_sites = context.sites[perm_site_idx]
    _, pep_id_inv = np.unique(perm_sites['peptide_id'], return_inverse=True)

    # Keep only decoy peptides that have no (isobaric) overlap with targets ...
    decoy_keep_pep_ids = np.setxor1d(same_pep_ids, decoy_sites['peptide_id'])
    # ... and all target peptides
    keep_pep_ids = np.unique(np.hstack([target_sites['peptide_id'], decoy_keep_pep_ids]))
    remove_pep_ids = np.delete(np.arange(context.fixed_mod_peptide_sequences.size), keep_pep_ids)
    # Peptide ids in the sites need to be adapted to new peptide
    for remove_pep_id in remove_pep_ids[::-1]:
        context.sites['peptide_id'][context.sites['peptide_id'] > remove_pep_id] -= 1

    # remove old sequences and add new permuted ones
    context.fixed_mod_peptide_sequences = np.hstack(
        [context.fixed_mod_peptide_sequences[keep_pep_ids], new_perm_seqs])

    # create new proteins for unique permuted decoy sequences
    old_prots = context.proteins[perm_sites['protein_id']]
    new_prots = np.copy(old_prots)
    new_prots['sequence'] = new_perm_seqs[pep_id_inv]
    new_prots['header'] = np.char.replace(old_prots['header'], 'DECOY', 'DECOY_PERMUTED')
    # append new proteins
    context.proteins = np.hstack([context.proteins, new_prots])

    # modify affected sites
    new_pep_ids = np.arange(context.fixed_mod_peptide_sequences.size - new_perm_seqs.size,
                            context.fixed_mod_peptide_sequences.size)
    new_prot_ids = np.arange(context.proteins.size - new_prots.size,
                             context.proteins.size)
    context.sites['peptide_id'][perm_site_idx] = new_pep_ids[pep_id_inv]
    context.sites['protein_id'][perm_site_idx] = new_prot_ids

    # sort the sites by peptide_id, required for the fixed mod table
    context.sites.sort(order='peptide_id')

    # return the new proteins, so we can save them to cache
    return new_prots


class ProteinDecoy(ABC):
    """Base Class for protein-based decoy generation."""

    def __init__(self, config):
        """
        Initialise the ProteinDecoy class.

        Parses the config and reads out the amino acids that the decoy-generation should be
        aware of.
        :param config: (Config) Search config.
        """
        self.specialAA = []
        self.detect_re = ''
        self.config = config
        if config.decoy.enzyme_aware:
            for e in config.digestion.enzymes:
                self.specialAA.extend(e.nterminal_of)
                self.specialAA.extend(e.cterminal_of)
                if len(e.cterminal_of) + len(e.nterminal_of) == 0:
                    raise AttributeError("Digestion can't be enzyme aware with an enzyme "
                                         "definition that does not specify amino-acids")

            self.specialAA = [x.encode('ASCII') for x in self.specialAA]
            self.detect_re = re.compile(b'(?<=[A-Z])(' + b'|'.join(self.specialAA) + b')+')
            self._generate = self._generate_digestion_aware
        else:
            self._generate = self._generate_digestion_unaware

        self.random = random.Random()
        self.random.seed(123456)

    def generate(self, sequence):
        """
        Wrapper around the _generate function that keeps N-term methionine in place.

        :param sequence: (bytes) Base sequence for decoy
        :return: (bytes) Decoy sequence
        """
        return_seq = b''
        if sequence.startswith(b'M'):
            sequence = sequence[1:]
            return_seq = b'M'
        return_seq += self._generate(sequence)
        return return_seq

    @abstractmethod
    def _generate_digestion_unaware(self, sequence):
        """
        Create decoy sequence unaware of digestion.

        :param sequence: (bytes) Base sequence for decoy
        :return: (bytes) Decoy sequence
        """
        ...

    @abstractmethod
    def _generate_digestion_aware(self, sequence):
        """
        Create decoy sequence taking the digestion into account.

        :param sequence: (bytes) Base sequence for decoy
        :return: (bytes) Decoy sequence
        """
        ...


class ReverseProtein(ProteinDecoy):
    """Class for generating decoy proteins by reversing the sequences."""

    def _generate_digestion_unaware(self, sequence):
        """
        Create a decoy sequence by reversing the residues.

        :param sequence: (bytes) Sequence to be reversed
        :return: (bytes) Reversed sequence
        """
        return b''.join(const.PEPTIDE_TO_AMINO_ACID.findall(sequence)[::-1])

    def _generate_digestion_aware(self, sequence):
        """
        Create a decoy sequence by reversing the residues, swapping digestable residues.

        Digestable residues are swapped with their preceding amino acid (post-reversal).
        :param sequence: (bytes) Sequence to be reversed
        :return: (bytes) Reversed sequence
        """
        rev = const.PEPTIDE_TO_AMINO_ACID.findall(sequence)[::-1]
        for aa in range(1, len(rev)):
            if rev[aa] in self.specialAA:
                temp = rev[aa]
                rev[aa] = rev[aa-1]
                rev[aa-1] = temp

        return b''.join(rev)


class ShuffleProtein(ProteinDecoy):
    """Class for generating decoy proteins by shuffling the sequences."""

    def _generate_digestion_unaware(self, sequence):
        """
        Generate a decoy sequence by shuffling the residues.

        :param sequence: (bytes) Sequence to be shuffled
        :return: (bytes) Shuffled sequence
        """
        aa_list = const.PEPTIDE_TO_AMINO_ACID.findall(sequence)
        self.random.shuffle(aa_list)
        return b''.join(aa_list)

    def _generate_digestion_aware(self, sequence):
        """
        Generate decoy sequence by shuffling the residues, keeping digestible residues in-place.

        :param sequence: the sequence to be shuffled
        :return: the shuffled sequence
        """
        aa_list = const.PEPTIDE_TO_AMINO_ACID.findall(sequence)
        shuffle_list = []
        shuffle_queue = []
        for aa in aa_list:
            if aa in self.specialAA:
                shuffle_list.append(aa)
            else:
                shuffle_list.append(None)
                shuffle_queue.append(aa)

        self.random.shuffle(shuffle_queue)

        for index, cv in enumerate(shuffle_list):
            if cv is None:
                shuffle_list[index] = shuffle_queue.pop()

        return b''.join(shuffle_list)


class RandomProtein(ProteinDecoy):
    """
    Class for creating decoy proteins by randomly selecting residues from the originating sequence.

    In effect that should be very similar to ShuffledProtein but does not enforce the exact same
    number of occurrences for each amino-acid.
    """

    def _generate_digestion_unaware(self, sequence):
        """
        Create a decoy sequence by randomly selecting amino-acids.

        :param sequence: (bytes) Sequence to be shuffled
        :return: (bytes) Shuffled sequence
        """
        aa_list = const.PEPTIDE_TO_AMINO_ACID.findall(sequence)
        aa_count = len(aa_list)

        ran_seq = [aa_list[self.random.randrange(0, aa_count)]
                   for _ in range(0, len(aa_list))]
        return b''.join(ran_seq)

    def _generate_digestion_aware(self, sequence):
        """
        Create a decoy sequence by randomly selecting amino-acids.

        In this version digestible residues are kept in-place

        :param sequence: the sequence to be shuffled
        :return: the shuffled sequence
        """
        aa_list = const.PEPTIDE_TO_AMINO_ACID.findall(sequence)
        random_source = list(aa_list)

        # remove the digested amino-acids from the available ones
        random_source = list(filter(lambda a: a not in self.specialAA, random_source))

        aa_count = len(random_source)

        ran_seq = []
        for aa in aa_list:
            if aa in self.specialAA:
                ran_seq.append(aa)
            else:
                ran_seq.append(random_source[self.random.randrange(0, aa_count)])

        return b''.join(ran_seq)


def get_decoy_mode(config):
    """
    Return the function to be used to generate decoys.

    :param config: (Config) Search config.
    :return: (function) Function to be used for generating decoy proteins.
    """
    if hasattr(config.decoy, "protein_decoy_function"):
        return config.decoy.protein_decoy_function

    elif config.decoy.mode == 'reverse':
        return ReverseProtein(config).generate

    elif config.decoy.mode == 'shuffle':
        return ShuffleProtein(config).generate

    elif config.decoy.mode == 'random':
        return RandomProtein(config).generate

    elif config.decoy.mode == 'none':
        return None

    else:
        raise ValueError(f"Unknown decoy generation method {config.decoy.mode}")
