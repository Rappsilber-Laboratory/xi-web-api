from xisearch2.search import SpectrumProcessor
from xisearch2.config import Config
from xisearch2.lookup import PeptideDatabase, FragmentDatabase
from xisearch2.spectra_reader import PeakListWrapper, Spectrum
from xisearch2 import dtypes
from xisearch2.cython import Fragmentation
import re
from xisearch2.modifications import Modifier
import numpy as np
from numpy.lib import recfunctions
from pyteomics import parser


def modified_peptides_from_sequences(base_sequences, modified_sequences, config):
    """
    Generate array form of modified peptides from original and modified sequences.

    Note this assumes unique modification names!
    :param base_sequences: (ndarray, bytes) original unmodified sequences
    :param modified_sequences: (ndarray, str) modified sequences
    :param config: (Config) search configuration

    :return: Table of the format (peptide_index, [nterm, cterm, AA0, .., AA-1])
             The values for nterm, cterm and AA refer to specific modifications (int).
    :rtype: np.ndarray
    """
    mod_names = [''] + [mod.name for mod in config.modification.modifications]

    if len(set(mod_names)) != len(mod_names):
        raise Exception('Creating the MockContext peptide database assumes unambiguous '
                        'modification names!')

    mod_indices = {name: i for i, name in enumerate(mod_names)}
    mod_indices['H-'] = 0
    mod_indices['-OH'] = 0

    result_dtype = [('sequence_index', np.intp),
                    ('modifications', np.uint8, (base_sequences.dtype.itemsize + 2,))]

    modified_peptides = np.zeros(len(modified_sequences), result_dtype)

    modifications = modified_peptides['modifications']
    sequence_indices = modified_peptides['sequence_index']

    parser_labels = parser.std_labels + ['U', 'O', 'X'] + mod_names

    for i, mod_sequence in enumerate(modified_sequences):
        parts = parser.parse(mod_sequence.decode('ascii'), show_unmodified_termini=True,
                             labels=parser_labels)
        nterm = parts[0]
        cterm = parts[-1]
        AAs = parts[1:-1]
        modifications[i, 0] = mod_indices[nterm]
        modifications[i, 1] = mod_indices[cterm]
        modifications[i, 2:len(parts)] = [mod_indices[AA[:-1]] for AA in AAs]
        sequence = ''.join([AA[-1] for AA in AAs]).encode('ascii')
        sequence_indices[i] = np.searchsorted(base_sequences, sequence)

    return modified_peptides


class MockContext():
    def __init__(self, config=Config(), all_tasks=1, this_task=0):
        self.config = config
        self.peptide_db = None
        self.fragment_db = None
        self.peptide_aa_lengths = None
        self.modified_peptides_aa_lengths = None
        self.modified_peptides = None
        self.unmodified_peptide_sequences = None
        self.site_info_table = None
        self.fixed_mod_peptide_sequences = None
        self.modifier = Modifier(self)
        self.fragmentation = Fragmentation(self)
        self.cluster = {"all_tasks": all_tasks, "this_task": this_task}

    def setup_peptide_db_xi2annotator(self, base_sequences, modification_ids,
                                      modification_positions):
        """
        Setup the peptide database for the xi2annotator .

        Based on base sequences, modification ids and positions.
        """
        # make unique and sort alphabetically
        self.unmodified_peptide_sequences = np.unique(base_sequences)

        # create modified peptides from the peptide sequences, modification ids and positions
        result_dtype = [('sequence_index', np.intp),
                        ('modifications', np.uint8,
                         (self.unmodified_peptide_sequences.dtype.itemsize + 2,))]
        self.modified_peptides = np.zeros(len(base_sequences), result_dtype)

        for i, (mod_ids, mod_positions, base_seq) in enumerate(
                zip(modification_ids, modification_positions, base_sequences)):
            self.modified_peptides['sequence_index'][i] = np.searchsorted(
                self.unmodified_peptide_sequences, base_seq)
            # input modification positions are 0-based, -1 is n-terminal, 32767 is c-terminal
            # xi2 modified peptides format (0 is n-terminal, 1 is c-terminal, then AAs)
            #
            # input modification ids: 0 is first modification in config, 1 is second, etc.
            # xi2 modification ids: 0 is unmodified, 1 is first modification in config, etc.
            # so we need to add 1 to the input modification ids
            for mod_id, mod_position in zip(mod_ids, mod_positions):
                if mod_position == 0:
                    self.modified_peptides['modifications'][i, 0] = mod_id + 1
                elif mod_position == 32767:
                    self.modified_peptides['modifications'][i, 1] = mod_id + 1
                else:
                    self.modified_peptides['modifications'][i, mod_position + 1] = mod_id + 1

        # sort them, so they match the unmodified_peptide_sequences array
        self.modified_peptides.sort()

        self.modified_peptides = recfunctions.append_fields(
            self.modified_peptides, names=['linear_only', 'var_mod_count'],
            dtypes=[np.bool_, np.uint8],
            data=[np.zeros(self.modified_peptides.size)] * 2, usemask=False)

        self.peptide_db = PeptideDatabase(self)
        self.peptide_aa_lengths = np.char.str_len(self.unmodified_peptide_sequences)
        self.modified_peptides_aa_lengths = self.peptide_aa_lengths[
            self.modified_peptides['sequence_index']]

    def setup_peptide_db(self, peptides, as_nterminal=False, as_cterminal=False,
                         modification_ids=None, modification_positions=None):
        self.fixed_mod_peptide_sequences = peptides

        # make unique and sort alphabetically
        self.unmodified_peptide_sequences = np.unique(
            [re.sub(b'[^A-Z]', b'', sequence) for sequence in peptides])

        if modification_ids is None or modification_positions is None:
            self.modified_peptides = modified_peptides_from_sequences(
                self.unmodified_peptide_sequences, peptides, self.config)
        else:
            # create modified peptides from the peptide sequences, modification ids and positions
            result_dtype = [('sequence_index', np.intp),
                            ('modifications', np.uint8,
                             (self.unmodified_peptide_sequences.dtype.itemsize + 2,))]
            self.modified_peptides = np.zeros(len(peptides), result_dtype)

            # input modification positions are 1-based, 0 is n-terminal, len+1 is c-terminal
            # convert to xi2 modified peptides format (0 is n-terminal, 1 is c-terminal, then AAs)
            for i, (mod_ids, mod_positions, pep_seq) in enumerate(
                    zip(modification_ids, modification_positions, peptides)):
                pep_seq = re.sub(b'[^A-Z]', b'', pep_seq)
                self.modified_peptides['sequence_index'][i] = np.searchsorted(
                    self.unmodified_peptide_sequences, pep_seq)
                for mod_id, mod_position in zip(mod_ids, mod_positions):
                    if mod_position == 0:
                        self.modified_peptides['modifications'][i, 0] = mod_id + 1
                    elif mod_position == len(peptides[i]) + 1:
                        self.modified_peptides['modifications'][i, 1] = mod_id + 1
                    else:
                        self.modified_peptides['modifications'][i, mod_position + 1] = mod_id + 1

        # sort them, so they match the unmodified_peptide_sequences array
        self.modified_peptides.sort()

        self.modified_peptides = recfunctions.append_fields(
            self.modified_peptides, names=['linear_only', 'var_mod_count'],
            dtypes=[np.bool_, np.uint8],
            data=[np.zeros(self.modified_peptides.size)] * 2, usemask=False)

        # calculate var_mod_count
        var_mod_idxs = np.array([m.index for m in self.config.modification.modifications if
                                 m.type == 'variable'])
        self.modified_peptides['var_mod_count'] = np.any(
            self.modified_peptides['modifications'] == var_mod_idxs.reshape(-1, 1, 1),
            axis=0).sum(axis=1)

        self.peptide_db = PeptideDatabase(self)
        self.peptide_aa_lengths = np.char.str_len(self.unmodified_peptide_sequences)
        self.modified_peptides_aa_lengths = self.peptide_aa_lengths[
            self.modified_peptides['sequence_index']]
        # Build modified peptide array
        self.site_info_table = np.empty(len(peptides), dtype=dtypes.site_info_table)
        self.site_info_table['sequence_index'] = np.arange(peptides.size)
        self.site_info_table['sites_first_idx'] = np.arange(peptides.size)
        self.site_info_table['sites_last_idx'] = np.arange(peptides.size)
        self.site_info_table['nterm'] = as_nterminal
        self.site_info_table['cterm'] = as_cterminal
        self.site_info_table['nterm_aa_block'] = False
        self.site_info_table['cterm_aa_block'] = False

        self.setup_fragment_db(self.unmodified_peptide_sequences)

    def setup_fragment_db(self, unmod_sequences):
        if self.modified_peptides is None:
            self.modified_peptides = np.empty(len(unmod_sequences), dtype=[
                ('sequence_index', np.intp),
                ('modifications', np.uint8, (unmod_sequences.dtype.itemsize + 2,))])
            self.modified_peptides['sequence_index'] = np.arange(len(unmod_sequences))
            self.modified_peptides['modifications'] = 0
        self.fragment_db = FragmentDatabase(self)

    def get_site_info_for_mod_pep_index(self, pep_index):
        return self.site_info_table[pep_index]


class SpectrumMock(Spectrum):
    def __init__(self, mz_array, int_array, charge_array, precursor=None):
        mz_array = np.asarray(mz_array)
        int_array = np.asarray(int_array)
        charge_array = np.asarray(charge_array)

        if precursor is None and len(charge_array) > 0:
            precursor = {'charge': np.max(charge_array)}
        Spectrum.__init__(self, precursor, mz_array, int_array, scan_id=0)
        self.isotope_cluster_peaks = np.array([(x, x)
                                               for x in range(len(mz_array))],
                                              dtype=dtypes.peak_cluster)
        self.isotope_cluster_intensity_values = int_array
        self.isotope_cluster_mz_values = mz_array
        self.isotope_cluster_charge_values = charge_array
        self.peak_has_cluster = np.asarray(charge_array, dtype=bool)


def get_pep_index_by_sequence(context, sequence):
    """Get the index into the peptide DB by sequence."""
    mod_sequences = context.peptide_db.mod_pep_sequence(np.arange(len(context.peptide_db.peptides)))
    pep_index = np.where(mod_sequences == sequence)[0]
    if len(pep_index) == 1:
        return pep_index[0]
    else:
        raise BaseException


def create_fasta(sequences, file_path):
    """Create a FASTA file from sequences."""
    file = open(file_path, 'w')
    for i, sequence in enumerate(sequences):
        if type(sequence) == bytes:
            sequence = sequence.decode()
        file.write(f'>sp|exampleP{i}|{sequence}\n')
        file.write(f'{sequence}\n')
    file.close()


class SearchRunner():
    def __init__(self, context):
        self.context = context

    def run_search(self, peaklist_file, result_writer):
        spectra_wrapper = PeakListWrapper(self.context)
        spectra_wrapper.load(peaklist_file)
        processor = SpectrumProcessor(self.context)
        for spectrum in spectra_wrapper.spectra:
            processor.process_spectrum(spectrum, result_writer)
        result_writer.close()


def compare_numpy(expected, found, cols=None, atol=1e-9, rtol=1.e-8, do_assert=True, do_print=True):
    """
    Compare two numpy structured arrays based on column types.
    Optionally differences can be printed and also the assert can be switched off.

    Non-numeric fields are compared for equality and numeric are compared with the given tolerance.
    All columns in expected need to be in found as well. Columns inf found that are not in
    expected are ignored

    :param expected (ndarray) - expected values
    :param found (ndarray) - found values to be compared against expected
    :param cols (None|List) - if not None a list of columns to be compared
                             if None then all columns in expected are compared.
    :param atol - absolute tolerance used for comparing numeric types
    :param rtol - relative tolerance for comparing numeric types
    :param do_assert - if differences are found raise an assertion.
                        assertions are raised at the end - after all differences where
                        collected/printed
    :param do_print - True: any found difference are printed out; False nothing is printed
    :return (list) of textual representation of differences
    """
    if cols is None:
        cols = expected.dtype.names
    all_err_msg = []
    for name in cols:
        # different sizes
        if len(expected[name]) != len(found[name]):
            msg = f'\n{name} doesnae match,\nexpected\n{expected[name]},\ngot\n{found[name]}'
            all_err_msg.append(msg)
            if do_print:
                print(msg)
        # numeric types
        elif np.issubdtype(found[name].dtype, np.number):
            if not np.allclose(found[name], expected[name], atol=atol, rtol=rtol, equal_nan=True):
                diff_value = (expected[name].astype(np.float64) - found[name].astype(np.float64))
                ppm_value = diff_value / expected[name]*1000000.0
                msg = f'\n{name} doesnae match,\nexpected\n{expected[name]},\ngot\n' \
                      f'{found[name]}\ndifference:\n' \
                      f'{diff_value}' \
                      f'\nppm difference:\n' \
                      f'{ppm_value}'
                all_err_msg.append(msg)
                if do_print:
                    print(msg)
        # generic comparison of non-numeric types
        else:
            if not np.all(found[name] == expected[name]):
                msg = f'\n{name} doesnae match,\nexpected\n{expected[name]},\ngot\n{found[name]}'
                all_err_msg.append(msg)
                if do_print:
                    print(msg)
    if do_assert:
        assert all_err_msg == []
    return all_err_msg
