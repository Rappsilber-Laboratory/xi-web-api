from sqlalchemy import Column, Integer, ForeignKey, ForeignKeyConstraint, Table, \
    PrimaryKeyConstraint, func, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.types import (
    VARCHAR,
    FLOAT,
    JSON,
    BOOLEAN,
    ARRAY,
    SMALLINT,
    Text,
    DateTime
)
from sqlalchemy.ext.declarative import declarative_base


base = declarative_base()

tbl_history = Table(
    "History",
    base.metadata,
    Column(
        "resultset_id",
        UUID,
        ForeignKey("ResultSet.id"),
        primary_key=True,
        nullable=False,
    ),
    Column(
        "parent_resultset_id",
        UUID,
        ForeignKey("ResultSet.id"),
        primary_key=True,
        nullable=False,
    ),
    quote=False
)

tbl_layout = Table(
    "Layout",
    base.metadata,
    Column("resultset_id", UUID, ForeignKey("ResultSet.id"), primary_key=True, nullable=False),
    Column("time_saved", DateTime(timezone=False), server_default=func.now(), primary_key=True,
           nullable=False),
    Column("layout", JSON, nullable=False),
    Column("description", Text, nullable=False),
    quote=False
)

tbl_match = Table(
    "Match",
    base.metadata,
    Column("id", UUID, primary_key=True, nullable=False),
    Column("search_id", UUID, ForeignKey("Search.id"), nullable=False),
    Column("pep1_id", Integer, nullable=False),
    Column("pep2_id", Integer, nullable=True),
    Column("site1", SMALLINT, nullable=True),
    Column("site2", SMALLINT, nullable=True),
    Column("link_score_site1", ARRAY(SMALLINT), nullable=True),
    Column("link_score_site2", ARRAY(SMALLINT), nullable=True),
    Column("link_score", ARRAY(FLOAT(precision=6)), nullable=True),
    Column("crosslinker_id", SMALLINT, nullable=True),
    Column("assumed_prec_mz", FLOAT, nullable=False),
    Column("assumed_prec_charge", SMALLINT, nullable=False),
    Column("calc_mass", FLOAT, nullable=False),
    Column("is_decoy", BOOLEAN, nullable=False),
    Column("is_dd", BOOLEAN, nullable=False),
    Column("score", FLOAT, nullable=False),
    Column("match_group_id", UUID, nullable=False, index=True),
    ForeignKeyConstraint(
        ["pep1_id", "search_id"],
        ["ModifiedPeptide.id", "ModifiedPeptide.search_id"],
    ),
    ForeignKeyConstraint(
        ["pep2_id", "search_id"],
        ["ModifiedPeptide.id", "ModifiedPeptide.search_id"],
    ),
    quote=False
)

tbl_matched_spectrum = Table(
    "MatchedSpectrum",
    base.metadata,
    Column(
        "match_id", UUID, ForeignKey("Match.id"), primary_key=True, nullable=False
    ),
    Column(
        "search_id", UUID, ForeignKey("Search.id"), primary_key=True, nullable=False
    ),
    Column(
        "spectrum_id",
        UUID,
        ForeignKey("Spectrum.id"),
        primary_key=True,
        nullable=False,
    ),
    Column(
        "matchedspectrum_type",
        SMALLINT,
        ForeignKey("MatchedSpectrumType.id"),
        nullable=False,
    ),
    quote=False
)

tbl_matched_spectrum_type = Table(
    "MatchedSpectrumType",
    base.metadata,
    Column("id", Integer, primary_key=True, nullable=False),
    Column("name", VARCHAR, nullable=False),
    quote=False
)

tbl_matched_peptide = Table(
    "ModifiedPeptide",
    base.metadata,
    Column("id", Integer, nullable=False),
    Column("search_id", UUID, nullable=False),
    Column("base_sequence", VARCHAR, nullable=False),
    Column("sequence", VARCHAR, nullable=False),
    Column("mass", FLOAT, nullable=False),
    Column("length", Integer, nullable=False),
    Column("modification_ids", ARRAY(Integer), nullable=True),
    Column("modification_position", ARRAY(Integer), nullable=True),
    Column("is_decoy", BOOLEAN, nullable=False),
    PrimaryKeyConstraint("search_id", "id"),
    quote=False
)

tbl_peaklist = Table(
    "PeakList",
    base.metadata,
    Column("id", UUID, primary_key=True, nullable=False),
    Column("search_id", UUID, ForeignKey("Search.id"), nullable=False),
    Column("name", VARCHAR, nullable=False),
    Column("path", VARCHAR, nullable=True),
    UniqueConstraint("search_id", "name", "path", name="peaklist_search_id_name_path_unique"),
    quote=False
)

tbl_peptide_position = Table(
    "PeptidePosition",
    base.metadata,
    Column("protein_id", Integer, primary_key=True, nullable=False),
    Column("mod_pep_id", Integer, primary_key=True, nullable=False, index=True),
    Column("start", Integer, primary_key=True, nullable=False),
    Column("search_id", UUID, primary_key=True, nullable=False),
    ForeignKeyConstraint(
        ["protein_id", "search_id"], ["Protein.id", "Protein.search_id"]
    ),
    ForeignKeyConstraint(
        ["search_id", "mod_pep_id"],
        ["ModifiedPeptide.search_id", "ModifiedPeptide.id"],
    ),
    quote=False
)

# Assuming that search_id should be a ForeignKey.
tbl_protein = Table(
    "Protein",
    base.metadata,
    Column("id", Integer, primary_key=True, nullable=False),
    Column(
        "search_id", UUID, ForeignKey("Search.id"), primary_key=True, nullable=False
    ),
    Column("accession", VARCHAR, nullable=True),
    Column("name", VARCHAR, nullable=True),
    Column("gen_name", VARCHAR, nullable=True),
    Column("description", VARCHAR, nullable=True),
    Column("sequence", VARCHAR, nullable=True),
    Column("full_header", VARCHAR, nullable=False),
    Column("is_decoy", BOOLEAN, nullable=False),
    quote=False
)

tbl_result_match = Table(
    "ResultMatch",
    base.metadata,
    Column(
        "resultset_id",
        UUID,
        ForeignKey("ResultSet.id"),
        primary_key=True,
        nullable=False,
    ),
    Column(
        "match_id", UUID, ForeignKey("Match.id"), primary_key=True, nullable=False
    ),
    Column(
        "search_id", UUID, ForeignKey("Search.id"), primary_key=True, nullable=False
    ),
    Column("scores", ARRAY(FLOAT(precision=6)), nullable=False),
    Column("match_group_id", UUID, nullable=False, index=True),
    Column("top_ranking", BOOLEAN, nullable=False, index=True),
    # xiSEARCH2 does not write site1, site2, link_score_site1, link_score_site2 and link_score
    # to the ResultMatch table, only to the Match table. The columns are only filled by
    # post-processing steps that modify their values.
    Column("site1", SMALLINT, nullable=True),
    Column("site2", SMALLINT, nullable=True),
    Column("link_score_site1", ARRAY(SMALLINT), nullable=True),
    Column("link_score_site2", ARRAY(SMALLINT), nullable=True),
    Column("link_score", ARRAY(FLOAT(precision=6)), nullable=True),
    quote=False
)

tbl_result_search = Table(
    "ResultSearch",
    base.metadata,
    Column(
        "resultset_id",
        UUID,
        ForeignKey("ResultSet.id"),
        primary_key=True,
        nullable=False,
    ),
    Column(
        "search_id", UUID, ForeignKey("Search.id"), primary_key=True, nullable=False
    ),
    quote=False
)

tbl_result_set = Table(
    "ResultSet",
    base.metadata,
    Column(
        "id", UUID, ForeignKey("ResultSet.id"), primary_key=True, nullable=False
    ),
    Column("name", VARCHAR, nullable=False),
    Column("note", VARCHAR, nullable=True),
    Column("rstype_id", Integer, ForeignKey("ResultSetType.id"), nullable=False),
    Column("config", Text, nullable=False),
    Column("main_score", Integer, nullable=False),
    quote=False
)

tbl_result_set_type = Table(
    "ResultSetType",
    base.metadata,
    Column("id", Integer, primary_key=True, nullable=False),
    Column("name", VARCHAR, nullable=False),
    quote=False
)

tbl_run = Table(
    "Run",
    base.metadata,
    Column("id", UUID, primary_key=True, nullable=False),
    Column("search_id", UUID, ForeignKey("Search.id"), nullable=False),
    Column("name", VARCHAR, nullable=False),
    UniqueConstraint('search_id', 'name', name='run_search_id_name_unique'),
    quote=False
)

tbl_score_name = Table(
    "ScoreName",
    base.metadata,
    Column(
        "resultset_id",
        UUID,
        ForeignKey("ResultSet.id"),
        primary_key=True,
        nullable=False,
    ),
    Column("score_id", Integer, primary_key=True, nullable=False),
    Column("name", VARCHAR, nullable=False),
    Column("primary_score", BOOLEAN, nullable=False),
    Column("higher_is_better", BOOLEAN, nullable=False),
    quote=False
)

tbl_search = Table(
    "Search",
    base.metadata,
    Column("id", UUID, primary_key=True, nullable=False),
    Column("name", VARCHAR, nullable=False),
    Column("config", JSON, nullable=False),
    Column("note", VARCHAR, nullable=True),
    quote=False
)

tbl_source = Table(
    "Source",
    base.metadata,
    Column("id", UUID, primary_key=True, nullable=False),
    Column("search_id", UUID, ForeignKey("Search.id"), nullable=False),
    Column("name", VARCHAR, nullable=False),
    Column("path", VARCHAR, nullable=True),
    UniqueConstraint('search_id', 'name', 'path', name='source_search_id_name_path_unique'),
    quote=False
)

tbl_spectrum = Table(
    "Spectrum",
    base.metadata,
    Column(
        "id", UUID, primary_key=True, nullable=False
    ),
    Column("ms_level", Integer, nullable=False),
    Column("precursor_mz", FLOAT, nullable=False),
    Column("precursor_charge", Integer, nullable=True),
    Column("precursor_intensity", FLOAT, nullable=True),
    Column("title", VARCHAR, nullable=False),
    Column("scan_number", Integer, nullable=True),
    Column("scan_index", Integer, nullable=False),
    Column("retention_time", FLOAT, nullable=True),
    Column("run_id", UUID, ForeignKey("Run.id"), nullable=True),
    Column("peaklist_id", UUID, ForeignKey("PeakList.id"), nullable=False),
    Column("source_id", UUID, ForeignKey("Source.id"), nullable=False),
    quote=False
)

tbl_spectrum_peaks = Table(
    "SpectrumPeaks",
    base.metadata,
    Column("id", UUID, ForeignKey("Spectrum.id"), primary_key=True, nullable=False),
    Column("mz", ARRAY(FLOAT), nullable=False),
    Column("intensity", ARRAY(FLOAT(precision=6)), nullable=False),
    quote=False
)
