"""
This module contains the PGResultWriter class for writing out xiSEARCH2 results to a postgres
database.

This one is split out, so that this file and the needed dependencies can be imported only when
needed.
"""
from xisearch2.result_writer import ResultWriter
from xisearch2.modifications import modified_sequence_strings
from xisearch2.xi_logging import log

from uuid import uuid4
from sqlalchemy import create_engine, MetaData, text
from sqlalchemy import Table as SATable
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import IntegrityError, NoResultFound
import numpy as np
import time
import random
import os
import traceback
import sys


def Table(name, *args, **kw):
    """Return an SQLAlchemy table but that uses the lower case table name.
    This is a workaround for the "quote=False" argument not working properly for the postgresql
    dialect in SQLAlchemy.
    :param name: name of the table - will be forwarded as lower case string.
    """
    return SATable(name.lower(), *args, **kw)


class PGResultWriter(ResultWriter):
    """
    Write results to the shared PostgresSQL database
    Implementation of a ResultWriter which outputs results into the
    tables of a Relational Database.

    Currently no batching is done. I.e. every match is writing every spectra one a at a time,
    with individual round trips to the DB. Might have to update to include some form of batch
    update.
    """

    def __init__(self, hostname, port, username, password, database, uuid_output, json_config,
                 context, result_set_name='', result_set_note=''):
        """
        Initialises the database connection and the writer in general.

        :param hostname: address of the database server
        :param username: database user name/role to use for the connection
        :param password: password of the user/role
        :param port: port the database server is listening to
        :param database: name of the DB to write the result out to
        :param uuid_output: a path where to write the uuid for the search
        :param json_config: the config JSON for the search
        :param context: the context object for the search
        :param result_set_name: the name of the result set to write
        :param result_set_note: the note for the result set to write
        """
        super().__init__(context)

        # Currently only MS2 Spectra are delt with
        self.default_ms_level = 2
        # Default Matched Specturm Type's id into the MatchedSpectrumTypes table
        self.default_matchedspectrum_type = 0
        # as what do we mark the result in the DB
        self.result_set_type = 0

        # Connection setup.
        # The 'engine' in SQLAlchemy is a Factory and connection pool to the
        # Xi results database. It has lazy initialisation.
        self.engine = create_engine(
            f"postgresql://{username}:{password}@{hostname}:{port}/{database}"
        )
        self.meta = MetaData()
        self.json_config = json_config
        self.search_uuid = context.search_uuid
        self.result_set_uuid = context.result_set_uuid
        self.result_set_name = result_set_name
        self.result_set_note = result_set_note
        self.uuid_output = uuid_output
        self.run_ids = {}
        self.source_path_ids = {}
        self.peaklist_ids = {}
        # an boolean array might be useful here - but requires late initialisation
        self.modified_peptide_written = np.zeros(len(self.context.modified_peptides), bool)

        score_cols = context.score_pipeline.score_columns
        self.score_names = [x if isinstance(x, str) else x[0] for x in score_cols]
        self.score_direction = [x if isinstance(x, str) else x[1] for x in score_cols]

        with self.engine.connect() as conn:

            # make sure we have the needed matched spectrum types in the DB
            self._init_matched_spectrum_types(conn)

            self._init_result_set_types(conn)

            self._prepare_search_tables(conn, self.search_uuid,
                                        self.result_set_uuid, self.json_config)

            # Write the Proteins table from the context
            self._write_protein(conn, self.search_uuid, self.context.proteins)

            self._write_score_names(conn, self.result_set_uuid)

        # setup table objects for batch inserts
        self.spectrum_table = Table("Spectrum", self.meta,
                                    autoload_with=self.engine, quote=False)
        self.spectrumpeaks_table = Table("SpectrumPeaks", self.meta,
                                         autoload_with=self.engine, quote=False)
        self.match_table = Table("Match", self.meta,
                                 autoload_with=self.engine, quote=False)
        self.matchedspectrum_table = Table("MatchedSpectrum", self.meta,
                                           autoload_with=self.engine, quote=False)
        self.modifiedpeptide_table = Table("ModifiedPeptide", self.meta,
                                           autoload_with=self.engine, quote=False)
        self.peptideposition_table = Table("PeptidePosition", self.meta,
                                           autoload_with=self.engine, quote=False)
        self.resultmatch_table = Table("ResultMatch", self.meta,
                                       autoload_with=self.engine, quote=False)

        # list of dictionaries for batch inserts
        self.spectrum_cache = []
        self.match_cache = []
        self.matchedspectrum_cache = []
        self.modifiedpeptide_cache = []
        self.peptideposition_cache = []
        self.resultmatch_cache = []
        self.spectrumpeaks_cache = []
        self.batch_size = context.config.result_writer.pg_batch_size

    def write(self, result):
        """
        Write all results for a single spectrum into a database.

        :param result: (SpectrumResult) object holding all matches to a single spectrum
        """
        # Using SQLAlchemy
        #  SQLAlchemy is using connection pooling by default - so only the first call to
        # `self.engine.connect()` should be expensive
        with self.engine.connect() as conn:
            # Generate a UUID for this spectrum result
            spectrum_uuid = uuid4()
            self._write_spectrum(conn, spectrum_uuid, result.spectrum)

            self._write_matches(conn, self.search_uuid, spectrum_uuid, result)

            if len(self.resultmatch_cache) > self.batch_size:
                self._writeout_batches(conn)

    def close(self):
        """
        Inform the writer that all data are writen.

        Currently only writes out the uuid to a file
        """
        with self.engine.connect() as conn:
            self._writeout_batches(conn)
        self._write_uuid_output_file()

    def _write_uuid_output_file(self, path=None):
        """write out the search uuid to a file"""
        if path is None:
            path = self.uuid_output
        if path is not None:
            with open(path, mode="w") as f:
                f.write(str(self.search_uuid))

    def _init_matched_spectrum_types(self, conn):
        """
       Make sure we have the needed matched spectrum types in the database.

       Currently "full match" is the only type used.
       """
        rs = conn.execute(
            text(
                'SELECT id, name FROM MatchedSpectrumType '
                "WHERE name = :name;"
            ),
            {"name": "full match"},
        )
        # If no default at 0, add it
        if rs.rowcount == 0:
            need_to_add = True
            while need_to_add:
                try:
                    # write the "full match" type into the db
                    conn.execute(
                        text(
                            'INSERT INTO MatchedSpectrumType ("id", "name") VALUES (:id, :name)'
                        ),
                        {"id": self.default_matchedspectrum_type, "name": "full match"},
                    )
                    need_to_add = False
                except IntegrityError:
                    # there is something else with that id - try a different one
                    self.default_matchedspectrum_type += 1
        else:
            row = rs.one()
            self.default_matchedspectrum_type = row.id

    def _init_result_set_types(self, conn):
        """
       Make sure we have the needed resultset types in the database.

       Currently "search result" is the only type used.
       """
        rs = conn.execute(
            text(
                'SELECT id, name FROM ResultSetType '
                "WHERE name = :name;"
            ),
            {"name": "search result"},
        )
        # If no default at 0, add it
        if rs.rowcount == 0:
            need_to_add = True
            while need_to_add:
                try:
                    # write the "search result" type into the db
                    conn.execute(
                        text(
                            'INSERT INTO ResultSetType ("id", "name") VALUES (:id, :name)'
                        ),
                        {"id": self.result_set_type, "name": "search result"},
                    )
                    need_to_add = False
                except IntegrityError:
                    # there is something else with that id - try a different one
                    self.result_set_type += 1
        else:
            row = rs.one()
            self.result_set_type = row.id

    def _write_peptide_position(self, conn, search_uuid, pep_id):
        """
        Writes out the peptide positions in Proteins.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: what is the search_uuid
        :param pep_id: index into context.modified_peptides
        """
        sites = self.context.get_sites_for_mod_pep_index(pep_id)
        for site in sites:
            self.peptideposition_cache.append({
                "protein_id": site["protein_id"].item(),
                "mod_pep_id": pep_id,
                "start": site["start"].item() + 1,
                "search_id": str(search_uuid)
            })

    def format_modifications(self, pep_modifications):
        """
        Convert the xiSEARCH internal format of modification into the database format.

        Converts the internal format (nterm-mod,cterm-mod,mod on first residue, mod on second
        residue,...) into the format used by the database. Two Arrays one for the modification
        position and one for the modification index.
        * first residue position is 0
        * nterm modification position is encoded as -1
        * cterm modification is encoded as 32767
        """
        modification_position = []
        modification_id = []

        # nterminal modification (before first residue)
        if pep_modifications[0].item() != 0:
            modification_position.append(0)
            modification_id.append(pep_modifications[0].item() - 1)

        # residue modifications
        for i in range(1, len(pep_modifications) - 1):
            if (pep_modifications[i + 1].item()) > 0:
                modification_position.append(i)
                modification_id.append(pep_modifications[i + 1].item() - 1)

        # cterminal modification (after last residue)
        if pep_modifications[1].item() != 0:
            modification_position.append(len(pep_modifications)-1)
            modification_id.append(pep_modifications[1].item() - 1)

        return {"positions": modification_position, "ids": modification_id}

    def _write_protein(self, conn, search_uuid, proteins):
        """
        Write out all proteins to the database.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: what is the search_uuid
        :param proteins: array of all proteins searched
        """
        protein_table = Table("Protein", self.meta, autoload_with=self.engine, quote=False)

        protein_values = []
        for id, protein in enumerate(proteins):
            protein_values.append(
                {
                    "id": id,
                    "search_id": str(search_uuid),
                    "accession": protein["accession"].item(),
                    "name": protein["name"].item(),
                    "gen_name": "",
                    "description": protein["description"].item(),
                    "sequence": protein["sequence"].item().decode('ascii'),
                    "full_header": protein["header"],
                    "is_decoy": protein["decoy"],
                }
            )

        stmt = insert(protein_table).values(protein_values)
        do_nothing_stmt = stmt.on_conflict_do_nothing()
        conn.execute(do_nothing_stmt)

    def _prepare_search_tables(self, conn, search_uuid, result_set_uuid, config):
        """
        Write out the meta information for the search.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: what is the search_uuid
        :param result_set_uuid: what is the uuid for the associated result set
        :param config: config JSON for the search
        """
        self._write_search(conn, search_uuid, config)
        self._write_result_set(conn, result_set_uuid, config)
        self._write_result_search(conn, search_uuid, result_set_uuid)

    def _write_search(self, conn, search_uuid, config):
        """
        Write out the search table.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: what is the search_uuid
        :param config: config JSON for the search
        """
        search = Table("Search", self.meta, autoload_with=self.engine, quote=False)
        stmt = insert(search).values(
            id=str(search_uuid),
            name="",  # TODO: either fill with the data from admin db or remove field
            config=config,
            note=None,
        )
        # could already be written by another cluster task for the same search
        do_nothing_stmt = stmt.on_conflict_do_nothing(index_elements=["id"])
        conn.execute(do_nothing_stmt)

    def _write_result_set(self, conn, result_set_uuid, config):
        """
        Write out a new entry into the result set table.

        :param conn: SQLAlchemy connection to use
        :param result_set_uuid: The UUID of the result set
        :param config: config JSON for the search
        """
        result_set = Table("ResultSet", self.meta, autoload_with=self.engine, quote=False)
        stmt = insert(result_set).values(
            id=str(result_set_uuid),
            name=self.result_set_name,
            note=self.result_set_note,
            rstype_id=self.result_set_type,
            config=config,
            main_score=self.score_names.index(self.context.score_pipeline.main_score),
        )
        # could already be written by another cluster task for the same search
        do_nothing_stmt = stmt.on_conflict_do_nothing(index_elements=["id"])
        conn.execute(do_nothing_stmt)

    def _write_result_search(self, conn, search_uuid, result_set_uuid):
        """
        Links the result_set to the search

        :param conn: SQLAlchemy connection to use
        :param search_uuid: what is the search_uuid
        :param result_set_uuid: The UUID of the result set
        """
        result_search = Table("ResultSearch", self.meta, autoload_with=self.engine, quote=False)
        stmt = insert(result_search).values(
            search_id=str(search_uuid),
            resultset_id=str(result_set_uuid),
        )
        do_nothing_stmt = stmt.on_conflict_do_nothing(
            index_elements=["search_id", "resultset_id"])
        conn.execute(do_nothing_stmt)

    def _write_spectrum(self, conn, uuid, spectrum):
        """
        Write out the data for a spectrum.

        :param conn: SQLAlchemy connection to use
        :param uuid: uuid identifier for the spectrum
        :param spectrum: The actual spectrum object
        """

        # The Run table stores the spectrum run_names.  Only new names are sent to
        # the Run table. The run_id is used to index from the specturm table.
        if spectrum.run_name == '':
            run_uuid = None  # sqlalchemy.sql.expression.null()
        else:
            # Check run_name, lookup run_id, or create if new run
            if spectrum.run_name in self.run_ids:
                run_uuid = self.run_ids[spectrum.run_name]
            else:
                # no yet found in this search task, ask the db for an id
                run_uuid = self._get_id(conn, 'Run', self.search_uuid, spectrum.run_name)
                if run_uuid is None:
                    run_uuid = uuid4()
                    run_uuid = self._write_run(conn, run_uuid, self.search_uuid, spectrum.run_name)
                self.run_ids[spectrum.run_name] = run_uuid

        # TODO: parse out the path
        default_peaklist_path = ''
        if spectrum.file_name == '':
            peaklist_uuid = None  # sqlalchemy.sql.expression.null()
        else:
            # Check run_name, lookup run_id, or create if new run
            if spectrum.file_name in self.peaklist_ids:
                peaklist_uuid = self.peaklist_ids[spectrum.file_name]
            else:
                peaklist_uuid = self._get_id(conn, 'PeakList', self.search_uuid, spectrum.file_name,
                                             default_peaklist_path)
                if peaklist_uuid is None:
                    peaklist_uuid = uuid4()
                    peaklist_uuid = self._write_peaklist(conn, peaklist_uuid, self.search_uuid,
                                                         spectrum.file_name, default_peaklist_path)
                self.peaklist_ids[spectrum.file_name] = peaklist_uuid

        # the source of the spectrum - could be either the peaklist file directly - or a archive
        # containing the actual peaklist file
        if spectrum.source_path == '':
            source_uuid = None  # sqlalchemy.sql.expression.null()
        else:
            # Check run_name, lookup run_id, or create if new run
            if spectrum.source_path in self.source_path_ids:
                source_uuid = self.source_path_ids[spectrum.source_path]
            else:
                path, filename = os.path.split(spectrum.source_path)
                source_uuid = self._get_id(conn, 'Source', self.search_uuid, filename, path)
                if source_uuid is None:
                    source_uuid = uuid4()
                    source_uuid = self._write_source(conn, source_uuid, self.search_uuid,
                                                     filename, path)
                self.source_path_ids[spectrum.source_path] = source_uuid
                # split path into filename/path

        self.spectrum_cache.append({
            "id": str(uuid),
            "ms_level": self.default_ms_level,
            "precursor_mz": spectrum.precursor["mz"],
            "precursor_charge": spectrum.precursor["charge"],
            "precursor_intensity": spectrum.precursor["intensity"],
            "title": spectrum.title,
            "scan_number": spectrum.scan_number,
            "scan_index": spectrum.scan_index,
            "retention_time": spectrum.rt,
            "run_id": str(run_uuid) if run_uuid else None,
            "peaklist_id": str(peaklist_uuid),
            "source_id": str(source_uuid),
        })
        # write out the spectrum peaks to a separate table
        self._write_spectrum_peaks(conn, uuid, spectrum.mz_values, spectrum.int_values)

    def _write_spectrum_peaks(self, conn, spectrum_uuid, mz_values, int_values):
        """
        Write out the peak-information of a spectrum to the spectrum_peaks table.

        :param conn: SQLAlchemy connection to use
        :param spectrum_uuid: uuid identifier for the spectrum
        :param mz_values: the m/z values for each peak
        :param int_values: The intensity values for each peak
        """
        # Note that the mz_values and int_values are numpy arrays so
        # need converting to python arrays for sqlalchemy to understand.
        self.spectrumpeaks_cache.append({
            "id": str(spectrum_uuid),
            "mz": mz_values.tolist(),
            "intensity": int_values.tolist()
        })

    def _get_id(self, conn, table, search_id, name, path=None):
        """
        Read out the uuid for a given name and search_id from a table from the database.

        Returns None if the name is not yet written to the table in the DB
        :param conn: SQLAlchemy connection to use
        :param table: the name of the DB table
        :param search_id: uuid identifier for the search
        :param name: the name of the item
        """
        tbl = Table(table, self.meta, autoload_with=self.engine, quote=False)
        try:
            if path is None:
                r = conn.execute(tbl.select().filter_by(search_id=str(search_id), name=name)).one()
            else:
                r = conn.execute(tbl.select().filter_by(search_id=str(search_id), name=name,
                                                        path=path)).one()
            uuid = r.id
        except NoResultFound:
            uuid = None
        return uuid

    def _write_run(self, conn, run_id, search_id, name):
        """
        Write out the uuid for the given run from the database.

        :param conn: SQLAlchemy connection to use
        :param run_id: uuid identifier for the run
        :param search_id: uuid identifier for the search
        :param name: run name
        """
        try:
            run_tbl = Table("Run", self.meta, autoload_with=self.engine, quote=False)
            stmt = insert(run_tbl).values(id=str(run_id), search_id=str(search_id), name=name)
            conn.execute(stmt)
            return run_id
        except IntegrityError:
            return self._get_id(conn, 'Run', search_id, name)

    def _write_peaklist(self, conn, uuid, search_id, name, path):
        """
        Write out the uuid for the given peaklist from the database.

        :param conn: SQLAlchemy connection to use
        :param uuid: uuid identifier for the peaklist
        :param search_id: uuid identifier for the search
        :param name: run name
        """
        try:
            peaklist_tbl = Table("PeakList", self.meta, autoload_with=self.engine, quote=False)
            stmt = insert(peaklist_tbl).values(
                id=str(uuid), search_id=str(search_id), name=name, path=path)
            conn.execute(stmt)
            return uuid
        except IntegrityError:
            return self._get_id(conn, 'PeakList', search_id, name, path)

    def _write_source(self, conn, uuid, search_id, name, path):
        """
        Write out the uuid for the given peak list source to the database.

        :param conn: SQLAlchemy connection to use
        :param search_id: uuid identifier for the search
        :param name: name of the peak list source
        :param path: path to the source
        """
        try:
            source_tbl = Table("Source", self.meta, autoload_with=self.engine, quote=False)
            stmt = insert(source_tbl).values(
                id=str(uuid), search_id=str(search_id), name=name, path=path)
            conn.execute(stmt)
            return uuid
        except IntegrityError:
            return self._get_id(conn, 'Source', search_id, name, path)

    def _create_modified_peptide_entry(self, conn, search_uuid, peptide_id, mass, aa_len, is_decoy):
        """
        Gather data for a modified peptide write it out to the DB.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: uuid identifier for the search
        :param peptide_id: index into context.modified_peptides (als the DB-ID)
        :param mass: mass of the peptide
        :param aa_len: number of amino acids in the peptide
        :param is_decoy: is this a decoy peptide
        """
        if not self.modified_peptide_written[peptide_id]:
            mods = self.context.modified_peptides[peptide_id][
                "modifications"
            ]
            formated_mods = self.format_modifications(mods)
            base_seq = self.context.peptide_db \
                .unmod_pep_sequence(peptide_id) \
                .decode('ascii')
            self._write_modified_peptide(
                conn,
                search_uuid,
                peptide_id,
                base_seq,
                mass,
                aa_len,
                formated_mods["ids"],
                formated_mods["positions"],
                is_decoy,
            )
            self._write_peptide_position(conn, search_uuid, peptide_id)
            self.modified_peptide_written[peptide_id] = True

    def _write_score_names(self, conn, result_set_uuid):
        """
        Write out the names of all scores considered during the search.

        :param conn: SQLAlchemy connection to use
        :param result_set_uuid: uuid identifier for the search
        """
        for i, col_name in enumerate(self.score_names):
            col_direction = self.score_direction[i]
            score_names_table = Table("ScoreName", self.meta, autoload_with=self.engine,
                                      quote=False)
            stmt = insert(score_names_table).values(
                resultset_id=str(result_set_uuid),
                score_id=i,
                name=col_name,
                primary_score=(col_name == self.context.score_pipeline.main_score),
                higher_is_better=col_direction,
            )
            # if run in a cluster another task might have already filled the score table
            do_nothing_stmt = stmt.on_conflict_do_nothing(
                index_elements=["score_id", "resultset_id"]
            )

            conn.execute(do_nothing_stmt)

    def _write_matches(self, conn, search_uuid, spectrum_uuid, result):
        """
        Write out the matches to a spectrum.

        Iterates over result.matches and writes each one out to the database.
        :param conn: SQLAlchemy connection to use
        :param search_uuid: uuid identifier for the search
        :param spectrum_uuid: uuid for the spectrum that was matched
        :param result: the search result for a match
        """
        match_group_uuid = uuid4()
        for match in result.matches:

            decoy_count = 0

            match_uuid = uuid4()
            pep1_id = match["p1_index"].item()
            first_prot = self.context.get_sites_for_mod_pep_index(pep1_id)[0]["protein_id"]

            is_decoy1 = self.context.proteins[first_prot]["decoy"]
            decoy_count += is_decoy1

            # Create a ModifiedPeptide for p1 and p2
            self._create_modified_peptide_entry(
                conn,
                search_uuid,
                pep1_id,
                match["mass_p1"].item(),
                match["aa_len_p1"].item(),
                is_decoy1
            )
            if match["p2_index"].item() >= 0:
                pep2_id = match["p2_index"].item()
                first_prot = self.context.get_sites_for_mod_pep_index(pep2_id)[0]["protein_id"]
                is_decoy2 = self.context.proteins[first_prot]["decoy"]
                decoy_count += is_decoy2
                self._create_modified_peptide_entry(
                    conn,
                    search_uuid,
                    pep2_id,
                    match["mass_p2"].item(),
                    match["aa_len_p2"].item(),
                    is_decoy2
                )

            site1 = match["link_pos_p1"] + 1
            site2 = match["link_pos_p2"] + 1

            link_site_rows = np.where(
                result.peptide_link_sites_info["alpha_beta_index"] == match['alpha_beta_index']
            )
            link_sites = result.peptide_link_sites_info[link_site_rows]

            calc_mass = match["calc_mass"]
            score = match["match_score"]

            self.match_cache.append({
                "id": str(match_uuid),
                "search_id": str(search_uuid),
                "pep1_id": match["p1_index"].item(),
                "pep2_id": match["p2_index"].item() if match["p2_index"].item() >= 0 else None,
                "site1": site1.item(),
                "site2": site2.item(),
                "link_score_site1": (link_sites["link_p1"] + 1).tolist(),
                "link_score_site2": (link_sites["link_p2"] + 1).tolist(),
                "link_score": link_sites["score"].tolist(),
                "crosslinker_id": match["crosslinker_index"].item() if match[
                    "crosslinker_index"].item() >= 0 else None,
                "assumed_prec_mz": match["precursor_mz"].item(),
                "assumed_prec_charge": match["precursor_charge"].item(),
                "calc_mass": calc_mass.item(),
                "score": str(score),
                "is_decoy": (decoy_count > 0),
                "is_dd": (decoy_count > 1),
                "match_group_id": str(match_group_uuid)
            })

            # Write a MatchedSpectrum entry for the new match
            self._write_matched_spectrum(conn, match_uuid, search_uuid, spectrum_uuid)

            self._write_resultmatch(conn, match_uuid, match_group_uuid, match)

    def _write_matched_spectrum(self, conn, match_uuid, search_uuid, spectrum_uuid):
        """
        Write out the linking between a match and the spectrum that it was matched against.

        Iterates ofer result.matches and writes each one out to the database.
        :param conn: SQLAlchemy connection to use
        :param match_uuid: uuid for the match
        :param search_uuid: uuid identifier for the search
        :param spectrum_uuid: uuid for the spectrum that was matched
        """
        self.matchedspectrum_cache.append({
            "match_id": str(match_uuid),
            "search_id": str(search_uuid),
            "spectrum_id": str(spectrum_uuid),
            "matchedspectrum_type": self.default_matchedspectrum_type,
        })

    def _write_resultmatch(self, conn, match_uuid, match_group_uuid, match):
        """
        Write out the resultmatches.

        :param conn: SQLAlchemy connection to use
        :param match_uuid: uuid for the match
        :param match_group_uuid: uuid for the match group, comprising all matches (alternative
            explanations) of a spectrum
        :param match: the xiSEARCH2 match
        """
        scores = [float(x.item()) for x in match[self.score_names]]

        self.resultmatch_cache.append({
            "resultset_id": str(self.result_set_uuid),
            "match_id": str(match_uuid),
            "search_id": str(self.search_uuid),
            "scores": scores,
            "top_ranking": match["top_ranking"],
            "match_group_id": str(match_group_uuid)
        })

    def _write_modified_peptide(self, conn, search_uuid, pep_id, base_sequence, mass,
                                length, mod_ids, mod_positions, is_decoy):
        """
        Gather data for a modified peptide write it out to the DB.

        :param conn: SQLAlchemy connection to use
        :param search_uuid: uuid identifier for the search
        :param pep_id: index into context.modified_peptides (als the DB-ID)
        :param base_sequence: the aminoacid sequence of the peptide without modifications
        :param mass: mass of the peptide
        :param length: number of amino acids in the peptide
        :param mod_ids: array of modification indexes (0 = first modfiication mentioned in the
        config)
        :param mod_positions: array of modification positions on the peptide
        :param is_decoy: is this a decoy peptide
        """

        self.modifiedpeptide_cache.append({
            "id": pep_id,
            "search_id": str(search_uuid),
            "base_sequence": base_sequence,
            "sequence": modified_sequence_strings(
                self.context.peptide_db.unmodified_sequences,
                self.context.peptide_db.peptides[[pep_id]],
                self.context.config,
                mod_position='Xmod')[0].decode('ascii'),
            "mass": mass,
            "length": length,
            "modification_ids": mod_ids,
            "modification_position": mod_positions,
            "is_decoy": is_decoy,
        })

    def _writeout_batches(self, conn, max_tries=10):
        """
        Write out the cached data to the database.

        To make it stable against the unexcpected (like intermitten databse failures) it will
        try to write out the data multiple times.

        :param conn: SQLAlchemy connection to use
        """

        # write out everything batch a single transaction and try again if something fails
        inserted = False
        tries = max_tries
        mod_pep_written = set()
        mod_peppos_written = set()
        while not inserted:
            try:
                if len(self.spectrum_cache) > 0:
                    stmt = insert(self.spectrum_table).values(self.spectrum_cache)
                    conn.execute(stmt)
                    self.spectrum_cache = []
                if len(self.spectrumpeaks_cache) > 0:
                    stmt = insert(self.spectrumpeaks_table).values(self.spectrumpeaks_cache)
                    conn.execute(stmt)
                    self.spectrumpeaks_cache = []

                # modified peptides can't writen in batches at the moment
                # as this can lead to deadlock situations (ask some experts?)
                if len(self.modifiedpeptide_cache) > 0:
                    # write each peptide out individually
                    for pep in self.modifiedpeptide_cache:
                        # but not if we now retry for some reason and this
                        # peptide was already written
                        if pep['id'] in mod_pep_written:
                            continue
                        # ok first time writing this peptide
                        stmt = insert(self.modifiedpeptide_table).values(pep)
                        do_nothing_stmt = stmt.on_conflict_do_nothing(
                            index_elements=["id", "search_id"]
                        )
                        conn.execute(do_nothing_stmt)
                        mod_pep_written.add(pep['id'])
                    self.modifiedpeptide_cache = []
                    mod_pep_written = set()

                if len(self.peptideposition_cache) > 0:
                    # write each peptide position out individually
                    for pep_pos in self.peptideposition_cache:
                        # but not if we now retry for some reason and this
                        # peptide was already written
                        if (pep_pos["protein_id"], pep_pos["mod_pep_id"]) in mod_peppos_written:
                            continue
                        # ok first time writing this peptide
                        stmt = insert(self.peptideposition_table).values(pep_pos)
                        do_nothing_stmt = stmt.on_conflict_do_nothing(
                            index_elements=["protein_id", "mod_pep_id", "search_id", "start"]
                        )
                        conn.execute(do_nothing_stmt)
                        mod_peppos_written.add((pep_pos["protein_id"], pep_pos["mod_pep_id"]))
                    self.peptideposition_cache = []
                    mod_peppos_written = set()
                if len(self.match_cache) > 0:
                    stmt = insert(self.match_table).values(self.match_cache)
                    conn.execute(stmt)
                    self.match_cache = []
                if len(self.matchedspectrum_cache) > 0:
                    stmt = insert(self.matchedspectrum_table).values(self.matchedspectrum_cache)
                    conn.execute(stmt)
                    self.matchedspectrum_cache = []
                if len(self.resultmatch_cache) > 0:
                    stmt = insert(self.resultmatch_table).values(self.resultmatch_cache)
                    conn.execute(stmt)
                    self.resultmatch_cache = []

                inserted = True
            except Exception as e:
                log("Error writing to database, will retry %d times" % tries)
                if tries == max_tries:
                    # first time we see an error, print the stack trace to stderr
                    traceback.print_exception(e, file=sys.stderr)
                    log(e)

                tries -= 1

                if tries == 0:
                    # we tried enough times, give up
                    raise e
                time.sleep(10 + random.random() * 10)
