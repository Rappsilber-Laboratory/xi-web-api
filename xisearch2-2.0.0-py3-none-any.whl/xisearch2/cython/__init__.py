"""Module to centralise import of all cython routines."""
from importlib import import_module
import numpy as np
import pyximport
import os


directory = os.path.dirname(__file__)
pyximport.install(setup_args={'include_dirs': np.get_include()}, inplace=True)
files = os.listdir(directory)

__all__ = []


def _get_name_for_attribute(search_module, search_attribute):
    """
    Return the name of an attribute.

    This is used to be able to have an export variable in each cython file that define what should
    be exported.

    :param search_module - the module that contains the attribute
    :param search_attribute - the attribute of which the name should be found
    """
    for aname in dir(search_module):
        if getattr(search_module, aname) is search_attribute:
            return aname
    return None


for filename in files:
    if filename.endswith(".pyx"):
        funcname = filename[:-4]
        modulename = "xisearch2.cython." + funcname
        module = import_module(modulename)
        mod_exports = []

        # try to find register array
        try:
            mod_exports = getattr(module, 'exports')
        except AttributeError:
            pass

        # if export was defined
        if len(mod_exports) > 0:
            attrib_to_name = {}
            # go through the exports
            for e in mod_exports:
                # find the name of it
                funcname = _get_name_for_attribute(module, e)
                # and add them to the list of public functions
                globals()[funcname] = e
                __all__.append(funcname)
        else:
            # no "export" list defined - so take the name of the file and export a function with
            # that name
            try:
                globals()[funcname] = getattr(module, funcname)
                __all__.append(funcname)
            except AttributeError:
                pass


