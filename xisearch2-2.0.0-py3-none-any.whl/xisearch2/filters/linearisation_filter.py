import numpy as np
from copy import copy
from xisearch2 import const
from xisearch2.filters.base_filter import BaseFilter
from xisearch2.filters.charge_reducer import ChargeReducer


class ChargeBasedLinearisationFilter(BaseFilter):
    """
    Linearise and charge reduce peaks in a isotope reduced (& charge_annotated) spectrum.

    Note: This is the legacy linearisation similar to the Xi1 code. Mass-based linearisation should
     produce better results.
    Peaks with charge state >2 are assumed to be crosslinker containing.
    Peaks with charge state =2 are duplicated as possible linear and crosslinker containing.
    Peaks with charge state <2 are assumed to be linear.

    1. Linear peaks get charge reduced and matched (intensities summed) using the ChargeReducer
     filter.

    2. Crosslinker containing fragments get charge reduced and then linearised by subtracting their
     mass from the precursor mass. These linear counterpart fragments get then matched against the
     linear peaks. On match the intensities are summed up. On no-match a new linear peak is added
     to the spectrum.

    """

    def process(self, spectrum):
        """
        Process a isotope_reduced (& charge_annotated) spectrum, returning a linearised version.

        :param spectrum: (Spectrum) isotope reduced & charge annotated spectrum
        :return: (Spectrum) A linearised copy of the spectrum
        """
        # check if input spectrum has charge annotations
        if spectrum.isotope_cluster_charge_values is None:
            raise ValueError("Spectrum has no charge annotations")
        output_spectrum = copy(spectrum)
        original_charges = spectrum.isotope_cluster_charge_values

        # linear cluster (original charge state <= 2)
        linear_mask = original_charges <= 2
        lin_mz = spectrum.isotope_cluster_mz_values[linear_mask]
        lin_int = spectrum.isotope_cluster_intensity_values[linear_mask]
        lin_charge = spectrum.isotope_cluster_charge_values[linear_mask]
        # create linear spectrum for charge reducing the linear peaks
        lin_spectrum = copy(spectrum)
        lin_spectrum.mz_values = lin_mz
        lin_spectrum.int_values = lin_int
        lin_spectrum.isotope_cluster_mz_values = lin_mz
        lin_spectrum.isotope_cluster_intensity_values = lin_int
        lin_spectrum.isotope_cluster_charge_values = lin_charge

        charge_reducer = ChargeReducer(self.context)

        lin_charge_reduced_spectrum = charge_reducer.process(lin_spectrum)
        lin_charge_reduced_mz = lin_charge_reduced_spectrum.isotope_cluster_mz_values
        lin_charge_reduced_int = lin_charge_reduced_spectrum.isotope_cluster_intensity_values
        lin_charge_reduced_charge = lin_charge_reduced_spectrum.isotope_cluster_charge_values

        # crosslinker containing peaks (original charge state >= 2)
        cl_mask = original_charges >= 2
        cl_mz = spectrum.isotope_cluster_mz_values[cl_mask]
        cl_int = spectrum.isotope_cluster_intensity_values[cl_mask]
        cl_charge = spectrum.isotope_cluster_charge_values[cl_mask]
        # calculate charge reduced mass values and set charges to 1
        cl_mass = (cl_mz - const.PROTON_MASS) * cl_charge
        cl_charge[:] = 1

        # Tolerance required for collapsing peaks after linearisation
        # ToDo LK: The commented out version is more correct (LF) but not used in Xi1 atm.
        #  Leaving it like this for now for better comparison to Xi1.
        # ms2_matched_tol = self.config.ms1_atol + \
        #     (spectrum.precursor_mass * self.config.ms1_rtol) + self.config.ms2_atol
        ms2_matched_tol = self.config.ms2_atol

        # Calculate new peaks to be shifted down - linearise crosslinked peaks
        linearized_cl_mz = spectrum.precursor_mass - cl_mass + const.PROTON_MASS

        # Check if any of the new peaks are close to any of the left-over peaks (non-shifted)
        overlaps = np.isclose(lin_charge_reduced_mz.reshape(-1, 1), linearized_cl_mz,
                              rtol=self.config.ms2_rtol, atol=ms2_matched_tol)

        lin_match_indices, linearized_match_indices = np.nonzero(overlaps)

        # These peaks were not matched to any linear peak
        non_matched_mask = ~np.any(overlaps, 0)
        non_matched_linearized_mz = linearized_cl_mz[non_matched_mask]
        non_matched_linearized_int = cl_int[non_matched_mask]
        non_matched_linearized_charge = cl_charge[non_matched_mask]

        # Update intensity array, sum of intensities
        lin_charge_reduced_int[lin_match_indices] += cl_int[linearized_match_indices]

        # Add the not matched linearized peaks to linear peaks
        new_mz = np.concatenate((lin_charge_reduced_mz, non_matched_linearized_mz))
        new_int = np.concatenate((lin_charge_reduced_int, non_matched_linearized_int))
        new_charge = np.concatenate((lin_charge_reduced_charge, non_matched_linearized_charge))

        # sort the arrays by mz
        mz_sort_indices = np.argsort(new_mz)

        # Modify the output linearized Spectrum obj
        output_spectrum.mz_values = new_mz[mz_sort_indices]
        output_spectrum.int_values = new_int[mz_sort_indices]
        output_spectrum.isotope_cluster_charge_values = new_charge[mz_sort_indices]

        # remove all peaks smaller than minimum amino acid mass
        # and all peaks larger than precursor - minimum amino acid mass
        lower_lim_mask = output_spectrum.mz_values > const.AMINO_ACID_MIN_MASS
        upper_lim_mask = output_spectrum.mz_values < \
            spectrum.precursor_mass - const.AMINO_ACID_MIN_MASS
        lim_mask = lower_lim_mask & upper_lim_mask
        output_spectrum.mz_values = output_spectrum.mz_values[lim_mask]
        output_spectrum.int_values = output_spectrum.int_values[lim_mask]
        output_spectrum.isotope_cluster_mz_values = output_spectrum.mz_values
        output_spectrum.isotope_cluster_intensity_values = output_spectrum.int_values
        output_spectrum.isotope_cluster_charge_values = \
            output_spectrum.isotope_cluster_charge_values[lim_mask]
        # Return the linearized Spectrum
        return output_spectrum


class MassBasedLinearisationFilter(BaseFilter):
    """
    Linearise peaks in a charge reduced spectrum to linear peaks.

    Assumes every peak above 0.5 neutral precursor mass is a crosslinker containing fragment.

    Crosslinker containing fragments get linearised by subtracting their mass from the precursor
    mass. These linear counterpart fragments get then matched against the linear peaks (< 0.5
    neutral precursor mass). On match the intensities are summed up. On no-match a new linear peak
    is added to the spectrum.
    """

    def process(self, spectrum):
        """
        Process a charge reduced spectrum, returning a linearised version.

        :param spectrum: (Spectrum) charge reduced spectrum
        :return: (Spectrum) A linearised copy of the charge reduced spectrum
        """
        # check for charge reduced spectrum
        if any(spectrum.isotope_cluster_charge_values > 1):
            spectrum = self.context.charge_filter.process(spectrum)
        output_spectrum = copy(spectrum)

        # Tolerance required for collapsing peaks after filtering
        ms2_matched_tol = self.config.ms1_atol + \
            (spectrum.precursor_mass * self.config.ms1_rtol) + self.config.ms2_atol

        # Check which peaks come from crosslinks (above 0.5 of neutral precursor mass)
        threshold = 0.5 * spectrum.precursor_mass
        xlinks_mask = spectrum.isotope_cluster_mz_values > threshold

        lin_mz_peaks = spectrum.isotope_cluster_mz_values[~xlinks_mask]
        lin_int_peaks = spectrum.isotope_cluster_intensity_values[~xlinks_mask]
        xlink_mz_peaks = spectrum.isotope_cluster_mz_values[xlinks_mask]
        xlink_int_peaks = spectrum.isotope_cluster_intensity_values[xlinks_mask]

        # Calculate new peaks to be shifted down - linearise xlink peaks
        xlink_mz_peaks = spectrum.precursor_mass - xlink_mz_peaks + 2 * const.PROTON_MASS

        # Check if any of the new peaks are close to any of the left-over peaks (non-shifted)
        overlaps = np.isclose(lin_mz_peaks.reshape(-1, 1), xlink_mz_peaks,
                              rtol=self.config.ms2_rtol, atol=ms2_matched_tol)

        lin_match_indices, linearized_match_indices = np.nonzero(overlaps)

        # These peaks were not matched to any linear peak
        non_matched_linearized_mz = xlink_mz_peaks[~np.any(overlaps, 0)]
        non_matched_linearized_int = xlink_int_peaks[~np.any(overlaps, 0)]

        # Update intensity array, sum of intensities
        lin_int_peaks[lin_match_indices] += xlink_int_peaks[linearized_match_indices]

        # Add the not matched linearized peaks to linear peaks
        linearized_mz = np.concatenate((lin_mz_peaks, non_matched_linearized_mz))
        linearized_int = np.concatenate((lin_int_peaks, non_matched_linearized_int))

        # sort the arrays by mz
        mz_sort_indices = np.argsort(linearized_mz)

        # Modify the output linearized Spectrum obj
        output_spectrum.mz_values = linearized_mz[mz_sort_indices]
        output_spectrum.int_values = linearized_int[mz_sort_indices]

        # remove all peaks smaller than minimum amino acid mass
        lower_lim_mask = output_spectrum.mz_values > const.AMINO_ACID_MIN_MASS

        output_spectrum.mz_values = output_spectrum.mz_values[lower_lim_mask]
        output_spectrum.int_values = output_spectrum.int_values[lower_lim_mask]

        output_spectrum.isotope_cluster_mz_values = output_spectrum.mz_values
        output_spectrum.isotope_cluster_intensity_values = output_spectrum.int_values
        output_spectrum.isotope_cluster_charge_values = np.full(output_spectrum.int_values.size, 1)

        # Return the linearized Spectrum
        return output_spectrum
