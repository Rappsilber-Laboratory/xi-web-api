"""Module for creating lookup-tables for fragments and peptides."""
from xisearch2.fragmentation import fragment_ions
from xisearch2.const import PROTON_MASS
from xisearch2.mass import mass
from xisearch2.modifications import modified_sequence_strings
from xisearch2.xi_logging import log
from xisearch2.cython import fast_lookup, fast_candidate_scores
from tempfile import TemporaryFile
from abc import ABC, abstractmethod
import numpy as np
import os


class MassDatabase(ABC):
    """Perform lookups against a database of (mass, id) pairs."""

    # Datatype for table entries
    table_dtype = np.dtype([('mass', np.float64), ('id', np.intp)])

    def __init__(self, mode='temp', dirname=None):
        """
        Initialise MassDatabase.

        :param mode: (str)
            'temp' builds the DB in an unnamed/unlinked temporary file (default)
            'load' loads the DB from an existing file
            'save' builds the DB in the named file
        :param dirname: directory name to use for load/save modes.
        """
        self.dirname = dirname

        # Validate arguments
        if mode not in ('temp', 'load', 'save'):
            raise ValueError("Invalid mode '%s'" % mode)
        elif mode == 'temp' and dirname is not None:
            raise ValueError("Directory name should not be given for 'temp' mode")
        elif mode != 'temp' and dirname is None:
            raise ValueError("Directory name must be given for '%s' mode" % mode)

        if dirname is not None:
            self.filename = os.path.join(self.dirname, "mass_table")

        if mode == 'load':
            # Load existing DB file
            table_file = open(self.filename, 'r+b')
            table = np.fromfile(table_file, self.table_dtype)
        elif mode in ('save', 'temp'):
            # Need to build the DB
            if mode == 'save':
                # Use named output file, creating required directories if needed
                if not os.path.exists(self.dirname):
                    os.makedirs(self.dirname)
                table_file = open(self.filename, 'w+b')
            else:
                # Open an anonymous file handle to build the table.
                table_file = TemporaryFile()
            # Build the table
            self.build_table(table_file)
            # read in the full file
            table_file.seek(0)
            table = np.fromfile(table_file, self.table_dtype)
            # Sort the table (by mass, and then by ID)
            log("Sorting database by mass and ID")
            table.sort()
            # and write it back
            table_file.seek(0)
            table_file.write(table)

        # View of the masses only.
        self.masses = table['mass']
        # View of the IDs only.
        self.ids = table['id']

    def lookup(self, masses, absolute_tolerance=0, relative_tolerance=0,
               return_matches=True, return_unique=False, return_counts=False):
        """
        Look up matching IDs for given masses.

        :param masses: Array of masses to be matched.
        :param absolute_tolerance: Absolute tolerance (+/- this value).
        :param relative_tolerance: Relative tolerance (+/- this fraction of absolute value).
        :param return_matches: If True, return a structured array with 'mass_index' and
                               'id' fields, indicating which masses match which IDs in the
                               database. The results are ordered by mass index.
        :param return_unique: If True, also return an array with the unique indices of
                              'masses' that matched the database.
        :param return_counts: If True, also return an array with the number of matches
                              for each unique index of 'masses' that matched the database.
        :return: As above.
        """
        # Convert masses to a 2d-array of floats if not already
        masses = np.atleast_2d(masses).astype(np.float64)
        # add delta_mass pseudo-masses
        if len(self.delta_masses) > 0:
            delta_mass_arrs = [masses - delta for delta in self.delta_masses]
            masses = np.concatenate([masses, np.vstack(delta_mass_arrs)])
        # Calculate combined tolerance for each mass based on real input masses
        tolerances = absolute_tolerance + masses[0] * relative_tolerance
        # Calculate upper and lower limits for each mass
        limits = np.array([(masses - tolerances).T, (masses + tolerances).T])
        # Call into cython implementation for fast search based on limits
        return fast_lookup(self.masses, self.ids, limits,
                           return_matches, return_unique, return_counts)

    def candidate_scores(self, num_candidates, fragment_masses, candidate_indices, score_offsets,
                         absolute_tolerance=0, relative_tolerance=0):
        """
        Score candidates according to matches of their fragments in the database.

        :param num_candidates: (int) Number of candidates.
        :param fragment_masses: (ndarray, float) Fragment masses to be matched.
        :param candidate_indices: (ndarray, int) Candidate indices associated with each fragment.
        :param score_offsets (ndarray, int) for each mass an offset for the found masses can be
                                            given. Useful for fragments from peptides not in the
                                            fragmentDB
        :param absolute_tolerance: (float) Absolute tolerance (+/- this value).
        :param relative_tolerance: (float) Relative tolerance (+/- this fraction of absolute value).

        :return: (ndarray, float) Scores for each candidate.
        """
        # Order input by candidate index.
        order = np.argsort(candidate_indices)
        candidate_indices = candidate_indices[order]
        score_offsets = score_offsets[order]
        fragment_masses = fragment_masses[order]

        # Calculate combined tolerance for each mass based on real input masses
        tolerances = absolute_tolerance + fragment_masses * relative_tolerance

        # Calculate upper and lower limits for each mass
        limits = np.empty((2, len(fragment_masses)))
        np.subtract(fragment_masses, tolerances, out=limits[0, :])
        np.add(fragment_masses, tolerances, out=limits[1, :])

        # Look up matching indices and counts
        return fast_candidate_scores(num_candidates, self.num_fragments, self.masses, limits,
                                     candidate_indices, score_offsets)

    @abstractmethod
    def build_table(self, table_file):
        """Build the lookup table in the given open file."""
        pass


class FragmentDatabase(MassDatabase):
    """Stores a database of peptides and their fragment masses, and supports lookups."""

    def __init__(self, context, mode='temp', dirname=None):
        """
        Initialise the FragmentDatabase.

        :param context: (Context): Search context
        :param mode: (str)
            'temp' builds the DB in an unnamed/unlinked temporary file (default)
            'load' loads the DB from an existing file
            'save' builds the DB in the named file
        :param dirname: Directory name to use for load/save modes.
        """
        self.sequences = context.unmodified_peptide_sequences
        self.modified_peptides = context.modified_peptides
        self.context = context

        # get stub masses from config
        if hasattr(context.config, 'crosslinker'):
            self.delta_masses = np.array(
                [s.mass for xl in
                 [allxl for allxl in context.config.crosslinker if hasattr(allxl, "stubs")]
                 for s in xl.stubs])
        else:
            self.delta_masses = np.array([])

        self.num_peptides = len(self.modified_peptides)

        # Initialise database
        MassDatabase.__init__(self, mode, dirname)

        self.num_fragments = len(self.masses)

    def build_table(self, table_file):
        """
        Generate the fragment table.

        :param table_file: where to write out the resulting table as file
        :return:
        """
        # Generator to produce combinations
        generator = fragment_ions(self.sequences,
                                  self.modified_peptides[~self.modified_peptides['linear_only']],
                                  self.context,
                                  add_precursor=True)

        # Write out a subtable for each ion type, loss type and loss count -
        # in practice this is just per ion type as we don't generate losses
        # at this stage.
        for term, ion, loss, loss_count, sites, masses in generator:

            peptide_indices = sites['peptide_index']

            mass_table = np.empty(len(sites), self.table_dtype)
            mass_table['mass'] = masses + PROTON_MASS
            mass_table['id'] = peptide_indices
            table_file.write(mass_table)


class PeptideDatabase(MassDatabase):
    """
    PeptideDatabase class that generates and stores peptide masses.

    Data structure to perform mass to peptide look-up. The index is build
    after initialization of the data structure with a list of peptides and
    masses.
    """

    def __init__(self, context, mode='temp', dirname=None):
        """
        Initialise PeptideDatabase.

        :param context: (Context): Search context
        :param mode: (str)
            'temp' builds the DB in an unnamed/unlinked temporary file (default)
            'load' loads the DB from an existing file
            'save' builds the DB in the named file
        :param dirname: Directory name to use for load/save modes.
        """
        self.config = context.config
        self.peptides = context.modified_peptides
        self.unmodified_sequences = context.unmodified_peptide_sequences
        MassDatabase.__init__(self, mode, dirname)
        self.reverse = np.argsort(self.ids)
        self.delta_masses = np.array([])

    def build_table(self, table_file):
        """
        Construct the peptide table with mass and id columns.

        :param table_file: where to write out the resulting table as file
        :return:
        """
        table = np.empty(self.peptides.size, self.table_dtype)
        table['id'] = np.arange(self.peptides.size)
        table['mass'] = mass(self.unmodified_sequences[self.peptides['sequence_index']],
                             modifications=self.peptides['modifications'],
                             config=self.config)
        table_file.write(table)

    def peptide_mass(self, peptide_index):
        """
        Return the mass of the peptide(s) with the given index.

        :param peptide_index: (int|ndarray) Single index or array of indices into the peptide DB
        :return: Mass of the peptide(s)
        :rtype: single float64 or ndarray (float64)
        """
        mass_index = self.reverse[peptide_index]
        return self.masses[mass_index]

    def unmod_pep_sequence(self, peptide_index):
        """
        Return unmodified peptide sequence(s).

        :param peptide_index: (int|ndarray) Single index or array of indices into the peptide DB
        :return: unmodified peptide sequence(s)
        :rtype: single byte string or ndarray (bytes)
        """
        unmod_pep_index = self.peptides['sequence_index'][peptide_index]
        return self.unmodified_sequences[unmod_pep_index]

    def mod_pep_sequence(self, peptide_index, mod_peptide_syntax=None):
        """
        Return modified peptide sequences.

        :param peptide_index: (ndarray) array of indices into the peptide DB
        :param mod_peptide_syntax: (str) syntax to use for modified peptides returned
            (defaults to config.mod_peptide_syntax)
        :return: modified peptide sequences
        :rtype: ndarray (bytes)
        """
        if mod_peptide_syntax is None:
            mod_peptide_syntax = self.config.mod_peptide_syntax

        mod_sequences = modified_sequence_strings(
            self.unmodified_sequences,
            self.peptides[peptide_index],
            self.config,
            mod_peptide_syntax
        )

        # correct linear sequences
        mod_sequences[peptide_index == -1] = b''

        return mod_sequences
