"""Module containing different filters for mass spectra."""
from xisearch2.filters.isotope_detector import IsotopeDetector
from xisearch2.filters.isotope_reducer import IsotopeReducer
from xisearch2.filters.charge_reducer import ChargeReducer
from xisearch2.filters.linearisation_filter import MassBasedLinearisationFilter, \
    ChargeBasedLinearisationFilter
from xisearch2.filters.denoise_filter import DenoiseFilter
from xisearch2.filters.loss_cluster_filter import LossClusterFilter
