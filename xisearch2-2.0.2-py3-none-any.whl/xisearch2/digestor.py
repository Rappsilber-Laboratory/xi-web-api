"""
Module for the Digestor class.

The Digestor cleaves proteins into peptides. During digestion
a peptide length filter and / or an approximate mass filter can be used.
"""
import re

import numpy as np

from xisearch2 import const
from xisearch2 import dtypes
from .xi_logging import ProgressBar, log


class Digestor(object):
    """Digestor class to transform proteins into peptides."""

    sites_dtype = dtypes.peptide_sites

    def __init__(self, context):
        """
        Initialise the Digestor.

        :param context (Searcher) Search context

        """
        self.context = context
        self.config = context.config

    def _cleave_parallel(self, enzymes, sequences, parent_sites=None):
        """
        Perform parallel in-silico digestion.

        :param enzymes: (list of Enzyme) all enzymes that digest in parallel
        :param sequences: (ndarray of bytes | list of list of bytes) sequences to digest in bytes
            string form or as list of modified amino acids (bytes strings)
        :param parent_sites: peptide sites from previous digestion step
        :return: peptide_sequences,
            peptide_sites
        :rtype: ndarray bytes,
            struct ndarray:
                ('peptide_id', '<i8')
                ('protein_id', '<i8')
                ('start', '<i8')
                ('end', '<i8')
                ('nterm', '?')
                ('cterm', '?')
                ('nterm_aa_block', '?')
                ('cterm_aa_block', '?')
        """
        # Lists to collect sub-arrays of peptides and sites found for each protein
        all_sequences = []
        all_sites = []

        # decide on the maximum amino acid length cut-off by taking the minimum of the
        # two constraints (amino acids in sequence and peptide mass)
        max_aa_cutoff = min(np.ceil(self.config.digestion.approx_max_mass
                            / const.AVG_AMINO_ACID_MASS), self.config.digestion.max_peptide_length)

        # Loop for parallel digestion
        for enzyme in enzymes:
            # Compile regular expression for finding cleavage sites
            rule = re.compile(enzyme.rule.encode('ascii'))
            bar = ProgressBar(f"Digesting proteins with {enzyme.name}", len(sequences))
            for protein_id, sequence in enumerate(sequences):
                # convert protein sequence to bytes if in mod aa list form
                if type(sequence) == list:
                    sequence = b''.join(sequence)
                # Find all cleavage sites
                cleavage_sites = [x.end() for x in rule.finditer(sequence)]
                # Peptide boundaries are the start and end of sequence, plus cleavage sites
                boundaries = np.sort(np.unique([0] + cleavage_sites + [len(sequence)]))
                # lookup for string position to amino acid positions
                aa_pos = {s: sum([1 for c in sequence[:s] if 65 <= c <= 90])
                          for s in boundaries}
                # How many adjacent cleaved chunks can be combined to count as one peptide.
                # We need one chunk to make each peptide even if no missed cleavages allowed.
                # The number of available chunks is one fewer than the number of boundaries.
                max_adjacent_combinations = min(self.config.digestion.missed_cleavages + 1,
                                                len(boundaries) - 1)
                # Collect the (start, end) spans for each possible peptide
                spans = np.vstack([np.vstack([boundaries[:-n], boundaries[n:]]).T
                                   for n in range(1, max_adjacent_combinations + 1)])
                # Extract sequences for each peptide
                pep_sequences = np.array([sequence[start:end] for start, end in spans])

                # create peptide positions array using the aa_pos lookup
                pep_positions = np.array([(aa_pos[start], aa_pos[end]) for start, end in spans])

                # Get peptide lengths (i.e. amino acid counts, not just string lengths)
                lengths = np.array([aa_end - aa_start for aa_start, aa_end in pep_positions])

                # Discard peptides below / above length limit
                valid_length_mask = (lengths >= self.config.digestion.min_peptide_length) \
                    & (lengths <= max_aa_cutoff)

                pep_sequences = pep_sequences[valid_length_mask]
                spans = spans[valid_length_mask]
                pep_positions = pep_positions[valid_length_mask]
                # Populate remaining peptide site information
                sites = np.empty(len(spans), self.sites_dtype)
                sites['protein_id'] = protein_id
                sites['start'] = pep_positions[:, 0]
                sites['end'] = pep_positions[:, 1]
                sites['nterm'] = (sites['start'] == 0)
                sites['cterm'] = (spans[:, 1] == len(sequence))
                # block peptide terminal amino acids that are crucial to digestion...
                if len(enzyme.nterminal_of) > 0:
                    # if they are not protein terminal
                    sites['nterm_aa_block'] = ~sites['nterm']
                else:
                    sites['nterm_aa_block'] = False
                if len(enzyme.cterminal_of) > 0:
                    sites['cterm_aa_block'] = ~sites['cterm']
                else:
                    sites['cterm_aa_block'] = False
                # Collect results from this protein
                all_sequences.append(pep_sequences)
                all_sites.append(sites)
                bar.next()

        bar.finish()

        # Combine results from all proteins
        all_sequences = np.concatenate(all_sequences)
        peptide_sites = np.concatenate(all_sites)

        # Throw out non-standard peptides e.g. containing X
        valid_sequences = (np.char.count(all_sequences, b'X') == 0)
        all_sequences = all_sequences[valid_sequences]
        peptide_sites = peptide_sites[valid_sequences]

        # Extract unique peptide sequences and the peptide IDs associated with each site
        peptide_sequences, peptide_indices, site_peptides = np.unique(all_sequences,
                                                                      return_index=True,
                                                                      return_inverse=True)
        peptide_sites['peptide_id'] = site_peptides

        # If given parent sites from a previous digestion step, refer the new site data back
        # to locations in the original protein sequences.
        if parent_sites is not None:
            log("Referring peptide sites to parent sites")
            new_sites = np.empty_like(peptide_sites)
            parents = parent_sites[peptide_sites['protein_id']]
            new_sites['protein_id'] = parents['protein_id']
            new_sites['peptide_id'] = peptide_sites['peptide_id']
            new_sites['start'] = parents['start'] + peptide_sites['start']
            new_sites['end'] = parents['start'] + peptide_sites['end']
            new_sites['nterm'] = parents['nterm'] & peptide_sites['nterm']
            new_sites['cterm'] = parents['cterm'] & peptide_sites['cterm']
            new_sites['nterm_aa_block'] = np.where(new_sites['start'] == parents['start'],
                                                   parents['nterm_aa_block'],
                                                   peptide_sites['nterm_aa_block'])
            new_sites['cterm_aa_block'] = np.where(new_sites['end'] == parents['end'],
                                                   parents['cterm_aa_block'],
                                                   peptide_sites['cterm_aa_block'])
            peptide_sites = new_sites

        # Remove duplicate sites
        peptide_sites = np.unique(peptide_sites)

        # Return unique peptide sequences and all sites they occur at in the original proteins.
        return peptide_sequences, peptide_sites

    def _cleave_sequential(self, sequences, sites=None):
        """
        Perform sequential in-silico digestion.

        The order of the enzymes in self.config.digestion.enzymes specifies the order of digestion.
        :param sequences: (ndarray of bytes | list of list of bytes) sequences to digest in bytes
            string form or as list of modified amino acids (bytes strings)
        :param sites: sites from previous digestion step
        :return: peptide_sequences,
            peptide_sites
        :rtype: ndarray bytes,
            struct ndarray:
                ('peptide_id', '<i8')
                ('protein_id', '<i8')
                ('start', '<i8')
                ('end', '<i8')
                ('nterm', '?')
                ('cterm', '?')
                ('nterm_aa_block', '?')
                ('cterm_aa_block', '?')
        """
        for enzyme in self.config.digestion.enzymes:
            sequences, sites = self._cleave_parallel(
                [enzyme], sequences, parent_sites=sites)

        # Remove duplicate sites
        sites = np.unique(sites)

        return sequences, sites

    def _cleave_n_terminal_methionine(self, proteins):
        """
        Cleaves protein with N-terminal methionine.

        If a protein N-terminal has a methionine, then the protein should be considered with and
        without the methionine. Effectively that s any N-terminal peptide that starts with
        methionine should be duplicated without the methionine.
        Any terminal modification should be kept also on the new methionine reduce peptide.
        :param proteins: (ndarray of bytes | list of list of bytes) proteins to cleave
        :return: proteins: sequences of proteins
                 sites: site information
        :rtype: ndarray bytes,
                ndarray int64,
                struct ndarray:
                    ('peptide_id', '<i8')
                    ('protein_id', '<i8')
                    ('start', '<i8')
                    ('end', '<i8')
                    ('nterm', '?')
                    ('cterm', '?')
                    ('nterm_aa_block', '?')
                    ('cterm_aa_block', '?')
        """
        sequences = []
        ids = []
        positions = []

        bar = ProgressBar("Cleaving N-terminal methionines", len(proteins))
        for protein_id, protein in enumerate(proteins):
            sequences.append(protein)
            ids.append(protein_id)
            # protein could be either bytes or list of modified amino acid bytes
            # transform to list of modified amino acid bytes if not already
            if type(protein) == bytes:
                protein = const.MODIFIED_AA_PATTERN.findall(protein)
            noncleaved_aa_len = len(protein)
            positions.append([0, noncleaved_aa_len])
            # check if the last char of the first mod amino acid is an M(the amino acid) of the
            if protein[0].endswith(b'M'):
                # cleave off methionine
                cleaved_protein = protein[1:]
                # apply protein fixed modifications (fixed protein mods needs byte string input)
                if type(cleaved_protein) == list:
                    cleaved_protein = b''.join(cleaved_protein)
                cleaved_protein = self.context.modifier.apply_protein_fixed_mods(
                    [cleaved_protein])[0]
                # append protein w/o methionine, same protein_id as original protein and 1 offset
                sequences.append(cleaved_protein)
                ids.append(protein_id)
                positions.append([1, noncleaved_aa_len])
            bar.next()
        bar.finish()

        sites = np.empty(len(sequences), dtype=dtypes.peptide_sites)
        sites['peptide_id'] = np.arange(sites.size)
        sites['protein_id'] = ids
        positions = np.array(positions)
        sites['start'] = positions[:, 0]
        sites['end'] = positions[:, 1]
        sites['nterm'] = True
        sites['cterm'] = True
        sites['nterm_aa_block'] = False
        sites['cterm_aa_block'] = False

        return sequences, sites

    def cleave(self, proteins):
        """
        Organize the cleavage of a complete list of proteins into peptides.

        Cleave stores the references for each peptide to the parent proteins.

        :param proteins: list or array of protein sequences

        :return: (array with unique peptide sequences, array with all peptide sites)

                 The sites array is a structured array with the following fields:
                     peptide_id: (int), index into array of unique peptide sequences
                     protein_id: (int), index into input array
                     start: (int), start amino acid position in the protein
                     end: (int), end amino acid position in the protein
                     nterm: (bool), whether this site is at the n-terminus of the protein
                     cterm: (bool), whether this site is at the c-terminus of the protein
        """
        proteins, sites = self._cleave_n_terminal_methionine(proteins)
        if self.config.digestion.mode == 'sequential':
            return self._cleave_sequential(proteins, sites)
        else:
            return self._cleave_parallel(self.config.digestion.enzymes, proteins, sites)
