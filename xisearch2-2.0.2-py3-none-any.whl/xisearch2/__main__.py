from multiprocessing import Process, Queue, Value, cpu_count
import queue as Q
from optparse import OptionParser
from .search import SearchContext, SpectrumProcessor
from .result_writer import TsvResultWriter, DummyResultWriter
from .load_test import LoadTest, load_test_config, RealDataLoadTest
from .xi_logging import log_enable, progress_enable, log, ProgressBar, log_file
from .config import Config, ConfigReader
from .cache import Cache
from .spectra_reader import PeakListWrapper
from multiprocessing import Pool
import tempfile
import sys
import os
import traceback

parser = OptionParser()
parser.add_option(
    "-f",
    "--fasta",
    dest="fasta",
    action="append",
    help="FASTA file with proteins to search against",
    metavar="DB",
)
parser.add_option(
    "-b",
    "--no-bar",
    dest="progress_bar",
    default=True,
    action="store_false",
    help="Show progress bar",
)
parser.add_option(
    "-c", "--config", dest="config", help="JSON configuration file", metavar="JSON"
)
parser.add_option(
    "-i",
    "--input",
    dest="mgf",
    action="append",
    help="MGF file with spectra to search",
    metavar="MGF",
)
parser.add_option(
    "-o",
    "--output",
    dest="tsv",
    help="TSV file to output search results",
    metavar="TSV",
)
parser.add_option(
    "-C",
    "--cache",
    dest="cache",
    help="Cache directory (default is system temp dir)",
    metavar="DIR",
)
parser.add_option(
    "-s",
    "--setup-only",
    dest="setup_only",
    default=False,
    action="store_true",
    help="Run setup only",
)
parser.add_option(
    "-l",
    "--load-test",
    dest="load_test",
    help="Run load test with N synthetic spectra",
    metavar="N",
    type="int",
)
parser.add_option(
    "-L",
    "--load-test-real",
    dest="load_test_real",
    help="Run load test with real data. Valid options: "
    + ", ".join(RealDataLoadTest.test_cases),
    metavar="TYPE",
    type="string",
)
parser.add_option(
    "-w",
    "--write-test",
    dest="write_test",
    action="store_const",
    const=tempfile.gettempdir(),
    help="Write out load test results to system temp dir",
)
parser.add_option(
    "-p",
    "--profile",
    dest="profile",
    default=False,
    action="store_true",
    help="Profile application code only",
)
parser.add_option(
    "-P",
    "--profile-all",
    dest="profile_all",
    default=False,
    action="store_true",
    help="Profile entire code stack",
)
parser.add_option(
    "-S",
    "--profile-statistic",
    dest="profile_statistic",
    default=False,
    action="store_true",
    help="Profile entire code stack",
)
parser.add_option(
    "--log",
    dest="log_file",
    help="Write logging output to file",
    metavar="TYPE",
    type="string",
)
parser.add_option(
    "-O",
    "--config-option",
    dest="additional_config_options",
    default=[],
    action="append",
    help="additional config-option to be evaluated",
)

parser.add_option(
    "--pg",
    action="store_true",
    dest="pg_sql",
    default=False,
    help="Enable writing output to PostgreSQL",
)

parser.add_option(
    '-n',
    '--pg-search-name',
    dest='result_name',
    help='Name for the new result set to write',
    metavar='NAME',
    default='',
)

parser.add_option(
    '-N',
    '--pg-search-note',
    dest='result_note',
    help='Note for the new result set to write',
    metavar='NOTE',
    default='',
)

parser.add_option(
    "--pg-hostname",
    dest="pg_hostname",
    default=None,
    help="Hostname of PostgreSQL server to connect to",
)

parser.add_option(
    "--pg-port",
    dest="pg_port",
    default=5432,
    help="TCP port to use for connecting to PostgreSQL",
)

parser.add_option(
    "--pg-username",
    dest="pg_username",
    default=None,
    help="Username to use for connecting to PostgreSQL",
)

parser.add_option(
    "--pg-password",
    dest="pg_password",
    default=None,
    help="Password to use for connecting to PostgreSQL",
)

parser.add_option(
    "--pg-database",
    dest="pg_database",
    default=None,
    help="Database to use after connecting to PostgreSQL",
)

parser.add_option(
    "--pg-uuid",
    dest="pg_uuid",
    default=None,
    help="search UUID - if not given a new one is generated",
)

parser.add_option(
    "--pg-uuid-output",
    dest="pg_uuid_output",
    default=None,
    help="File to write the resulting search UUID",
)
parser.add_option("-t", "--task",
                  dest="cluster_task",
                  default=0, type='int', metavar="N",
                  help="defines that this is the nth task of all tasks (zero based)")
parser.add_option("-T", "--total-tasks",
                  dest="cluster_all_tasks",
                  default=1, type='int', metavar="N",
                  help="in how many tasks is the search split up")

(options, args) = parser.parse_args()
if options.profile_all:
    options.profile = True
if options.profile_statistic:
    options.profile = True

log_enable(True)
if options.log_file:
    log_file(options.log_file)

progress_enable(options.progress_bar)


def fail(message):
    print(message)
    sys.exit(1)


def validate_options(options):
    if options.pg_sql:
        if not options.pg_hostname:
            fail("PG hostname is required with PG result writer")
        if not options.pg_username:
            fail("PG username is required with PG result writer")
        if not options.pg_database:
            fail("PG database is required with PG result writer")
        if (not options.pg_uuid_output) and options.pg_uuid is None:
            fail("PG UUID Output is required with PG result writer")

    if options.load_test and options.load_test_real:
        fail("Choose either synthetic data or real data load test")
    if options.load_test or options.load_test_real:
        if options.mgf:
            fail("Load test is mutually exclusive with MGF file_name")
        if options.tsv:
            fail("TSV output is not supported for load test")
    else:
        if options.write_test:
            fail("write-test requires load-test option")
        if not options.mgf:
            fail("MGF spectra file_name is required")
        if not options.pg_sql and not options.tsv:
            fail("TSV output file_name is required when not using PG result writer")

    # check if we have valid settings for split processing
    if options.cluster_task is not None:
        if options.cluster_task >= options.cluster_all_tasks:
            raise ValueError('"task" (-t) has to be smaller then "all tasks" (-T)')


def write_queue(queue, keep_writing, writing_finished):
    while keep_writing.value:
        try:
            s = queue.get(True, 1)
            while len(s.matches) > 0:
                for rw in result_writer:
                    rw.write(s)
                s = queue.get(False)
        except Q.Empty:
            ...
    for rw in result_writer:
        rw.close()
    writing_finished.value = True


if not options.fasta and not options.load_test_real:
    fail("FASTA protein database file_name is required")

# Select cache
if options.cache:
    cache_directory = options.cache
else:
    cache_directory = os.path.join(tempfile.gettempdir(), "xisearch2", "cache")

log("Cache directory used: " + cache_directory)

# Create cache directory if it does not exist yet
if not os.path.exists(cache_directory):
    os.makedirs(cache_directory)

cache = Cache(cache_directory)

if options.load_test:
    test = LoadTest(cache, n_spectra=options.load_test)
    config = load_test_config
elif options.load_test_real:
    test = RealDataLoadTest(options.load_test_real)
    options.fasta = test.fasta
    config = test.config
elif options.config:
    config = ConfigReader.load_file(options.config)
else:
    config = Config()

for o in options.additional_config_options:
    exec("config." + o)

context = SearchContext(options.fasta, config, cache, search_uuid=options.pg_uuid,
                        this_task=options.cluster_task, all_tasks=options.cluster_all_tasks)
processor = SpectrumProcessor(context)

# define function to process each spectra
if options.progress_bar:

    def main(spectrum):
        try:
            processor.process_spectrum(spectrum, result_queue)
            bar_queue.put(True)
        except Exception:
            traceback.print_exc()
            return False
        return True

else:

    def main(spectrum):
        try:
            processor.process_spectrum(spectrum, result_queue)
        except Exception:
            traceback.print_exc()
            return False
        return True


if __name__ == "__main__":
    # Validate argument combinations
    result_writer = []
    validate_options(options)
    # Setup search
    if options.load_test or options.load_test_real:
        test.setup(context)
        if options.setup_only:
            sys.exit(0)

        options.mgf = test.mgf
        if options.write_test:
            out_file = os.path.join(options.write_test, "load_test.tsv")
            result_writer.append(TsvResultWriter(out_file, context))
        else:
            result_writer.append(DummyResultWriter(context))

    else:
        if options.setup_only:
            sys.exit(0)

        if options.pg_sql:
            from .pg_result_writer import PGResultWriter
            json_config = open(options.config, "r").read()
            result_writer.append(PGResultWriter(
                options.pg_hostname,
                options.pg_port,
                options.pg_username,
                options.pg_password,
                options.pg_database,
                options.pg_uuid_output,
                json_config,
                context,
                options.result_name,
                options.result_note,
            ))

        if options.tsv:
            result_writer.append(TsvResultWriter(options.tsv, context))

    # The multiprocessing queue that we use to get data to the writer. The Spectrum
    # Processors will be writing to this and the queue_writer reads from it.
    result_queue = Queue()
    # This is a shared value to be used with the writer process: it allows us to let
    # the writer know that we are done processing and the writer can close itself.
    keep_writing = Value("b", True)
    # Shared value to get feedback from the writer when it is done writing out.
    writing_finished = Value("b", False)
    # Setting 'daemon=True' below means that if the main process dies (eg, because of
    # an error) the writer will die as well. This means, however, that we must take
    # care to deal with the writer carefully or we could lose data. That is why we
    # call writer_process.join() at the end of this method.
    writer_process = Process(
        target=write_queue,
        args=(result_queue, keep_writing, writing_finished),
        daemon=True,
    )
    writer_process.start()

    log("Loading spectra")
    spectra_wrapper = PeakListWrapper(context)
    spectra_wrapper.load(options.mgf)
    num_spectra = spectra_wrapper.count_spectra()
    log("Loaded %d spectra, starting search" % num_spectra)

    if options.progress_bar:
        bar_queue = Queue()
        bar = ProgressBar("Processing spectra", num_spectra)

        def bar_updater(queue):
            while True:
                s = queue.get()
                if s:
                    bar.next()
                else:
                    return

        bar_process = Process(target=bar_updater, args=(bar_queue,), daemon=True)
        bar_process.start()

    if options.profile:
        if options.profile_statistic:
            try:
                from pprofile import StatisticalProfile
            except ImportError:
                print("The StatisticalProfile module could not be imported - run pipenv -d "
                      "install")
                exit()
            profile = StatisticalProfile()
        else:
            try:
                from pprofile import Profile
            except ImportError:
                print("The Profile module could not be imported - run pipenv -d "
                      "install")
                exit()
            profile = Profile()

        with profile():
            for spectrum in spectra_wrapper.spectra:
                main(spectrum)
        if options.profile_all:
            filenames = profile.getFilenameSet()
        else:
            filenames = {
                f
                for f in profile.getFilenameSet()
                if f.startswith(os.path.dirname(__file__))
            }
        with open("callgrind.out", "w+") as f:
            profile.callgrind(f, commandline=" ".join(sys.argv), filename=filenames)

    else:
        thread_count = config.threads
        if thread_count == 0:
            thread_count = None  # multithreading doesn't like 0 as a value
        elif thread_count < 0:
            thread_count = cpu_count() + thread_count
        if thread_count == 1:
            for s in spectra_wrapper.spectra:
                main(s)
        else:
            thread_pool = Pool(thread_count)
            # process spectra across threads
            for r in thread_pool.imap_unordered(main, spectra_wrapper.spectra, 10):
                if not r:
                    raise Exception(
                        "Exception occurred during main search! See stack trace above for details."
                    )

            # https://pytest-cov.readthedocs.io/en/latest/subprocess-support.html#if-you-use-multiprocessing-pool
            thread_pool.close()  # Marks the pool as closed.
            thread_pool.join()  # Waits for workers to exit.

    # end progress bar
    if options.progress_bar:
        bar.finish()

    # tell the writer we're done and wait for it to stop
    keep_writing.value = False
    # Not sure why we need the next 5 lines, just a `writer_process.join()` should be
    # enough. But for some reason, the writer_process doesn't always die, and then the
    # `join` doesn't return.
    log("Search finished, waiting for result writer to complete...")
    result_queue.close()
    result_queue.join_thread()
    writer_process.join(1)
    write_wait_time = 0
    while not writing_finished.value:
        log("Writing not finished. Still waiting...")
        writer_process.join(30)
        write_wait_time += 30
        if write_wait_time >= 1800:
            write_time_out_msg = (
                "Writing timeout! Writing did not finish in 30 minutes."
            )
            log(write_time_out_msg)
            raise Exception(write_time_out_msg)

    log("Finished search!")
    log(False)
