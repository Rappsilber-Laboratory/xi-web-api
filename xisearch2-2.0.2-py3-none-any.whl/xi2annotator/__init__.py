from xi2annotator.app import *
from xi2annotator.config import *
from flask import Blueprint

bp = Blueprint('xi2annotator', __name__)
from xi2annotator import routes
