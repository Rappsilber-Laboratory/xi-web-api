import os

from flask import Flask
from flask_cors import CORS


def create_app():
    """
    Create the flask app.

    Currently only used for annotation.
    :return: flask app
    """
    app = Flask(__name__)

    # Load flask config
    if os.environ.get('FLASK_ENV', 'production') == 'development':
        app.config.from_object('xi2annotator.config.DevelopmentConfig')
    else:
        app.config.from_object('xi2annotator.config.ProductionConfig')
        try:
            app.config.from_envvar('XI2ANNOTATOR_SETTINGS')
        except (FileNotFoundError, RuntimeError):
            ...

    # add CORS header
    CORS(app, resources={
        r"/xiAnnotator/annotate/FULL": {
            "origins": "*",
            "headers": app.config['CORS_HEADERS']
        }
    })

    from xi2annotator import bp
    app.register_blueprint(bp)

    return app
